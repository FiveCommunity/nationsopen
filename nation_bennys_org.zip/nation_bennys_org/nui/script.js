let vehicle = [];
let Bennys = "<img src='https://vignette.wikia.nocookie.net/gtawiki/images/b/be/BennysOriginalMotorWorks-GTAO-Logo.png/revision/latest?cb=20160623123158'></img>";
let actionContainer = $("#actionmenu");
let audioPlayer = null;
let audioPlayer2 = null;
let canbuy = false;
let blocked = false;
let resourceName = "nation_bennys";
$(document).ready(function(){
//	showMenu("mainMenu", Bennys);
	window.addEventListener("message",function(event){
		let item = event.data;
		switch(item.action){
			case "resourceName":
				resourceName = item.resourceName;
			break;

			case "showMenu":
				init(item);
			break;

			case "hideMenu":
				actionContainer.slideUp(500);
				$("#voltar").slideUp(500);;
				$("#pagar").slideUp(500);
				$("#repair").slideUp(500);
			break;

			case "vehicle":
				vehicle = item.vehicle;
				if (item.logo) {
					Bennys = `<img src="`+item.logo+`">`;
				}
				if (item.damage < 995) {
					$("#repair").show();
					actionContainer.addClass('prevent-click');
				} else {
					actionContainer.removeClass('prevent-click');
				}
			break;

			case "applying":
				actionContainer.addClass('prevent-click');
			break;

			case "repair":
				$("#repair").slideUp();
				actionContainer.removeClass('prevent-click');

			case "cam":
				blocked = true;
				$("#cam").html(lang.freeCam)
				audioPlayer = new Audio("https://www.zapsplat.com/wp-content/uploads/2015/sound-effects-pmsfx/PM_TS_Camera_Film_35mm_SLR_PRACTIKA_DTL3_MKH8040_28_Shutter_Release_1_60th_28.mp3?_=1");
				audioPlayer.volume = 0.05;
				let playPromise = audioPlayer.play();
				if (playPromise !== undefined) {
					playPromise.then(_ => {
					})
					.catch(error => {
					});
				}
			break;

			case "price":
				canbuy = true;
				if (item.price > 0) {
					$("#preco").html(item.price);
				} else {
					$("#preco").html(0);
					$("#pagar").slideUp(500);
				}
			break;
		}
	});

	document.onkeyup = function(data){
		if (data.which == 27){
			$.post("https://"+resourceName+"/close");
		} else if (data.which == 72) {
			if (blocked) {
				blocked = false;
				return;
			}
			$.post("https://"+resourceName+"/cam", JSON.stringify({
					cam: "freecam"
			}));
			$("#cam").html(lang.backCam)
			audioPlayer = new Audio("https://www.zapsplat.com/wp-content/uploads/2015/sound-effects-pmsfx/PM_TS_Camera_Film_35mm_SLR_PRACTIKA_DTL3_MKH8040_28_Shutter_Release_1_60th_28.mp3?_=1");
			audioPlayer.volume = 0.05;
			let playPromise = audioPlayer.play();
			if (playPromise !== undefined) {
				playPromise.then(_ => {
				})
				.catch(error => {
				});
			}
		}
	};
});



function init(item) {
	let options = item.options;
	if (options) { 
		opcoes = options; 
		if (item.pneus) pneus = item.pneus;
	} else { 
		opcoes = oldOptions;
		pneus = oldPenus;
	}
	if (item.logo) {
		Bennys = `<img src="`+item.logo+`">`;
	}
	opcoes.map((op) => {
		let old = oldOptions.find((obj) => obj.nome == op.nome);
		if (old) {
			op.id = old.id;
			op.img = "https://nation-resources.me/images/nation_bennys/"+(op.id || op.nome)+".png";
		}
	});
	$("#menu").hide();
	actionContainer.slideDown(500);
	showMenu("mainMenu", Bennys);
	$("#voltar").attr("data-action", "mainMenu");
	$("#sair").show();
	$("#preco").html("0");
	$("#cam").html(lang.freeCam);
	canbuy = false;
}

let opcoes = [
	{ nome: 'aerofolio', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981131541942303/spoiler.png?ex=65ec8910&is=65da1410&hm=d56b2ddd70442aa4971981bd574a0eaf11db1477ec8f33621571ae0d0d4fde21&" },
	{ nome: 'parachoque dianteiro', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981020489359491/front_bumper.png?ex=65ec88f6&is=65da13f6&hm=15a8de2f2fc577a8b26df9874ded8e2898555e3eae2aa9e4cc4e7d7c5464a377&", id: "parachoque-dianteiro" },
	{ nome: 'parachoque traseiro', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981129428144180/rear_bumper.png?ex=65ec8910&is=65da1410&hm=7bf2217c8f1258558772f0030c3d789f69b4f2e1f1a8460e24867195ac430ead&", id: "parachoque-traseiro" },
	{ nome: 'saias', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981130850017420/side_skirt.png?ex=65ec8910&is=65da1410&hm=7c6ddfe3d091379b9f0bee6fe2ea6bcc8870cda076bc13eb968baa2f818c9a3d&" },
	{ nome: 'escapamento', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981019696631929/exhaust.png?ex=65ec88f6&is=65da13f6&hm=a1066d3a786d45a76b0683a10cac927c2fbcee0907137fff27646cbd8b2307e7&" },
	{ nome: 'chassi', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210980957524459520/chassis.png?ex=65ec88e7&is=65da13e7&hm=179c19e842a11ed55cb640639299a5ce5c51b3b94b03438c484dba9c93bb35f1&" },
	{ nome: 'grelha', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981020955058216/grille.png?ex=65ec88f6&is=65da13f6&hm=ad6d75312e3f9b0d065e9cca411bb0587908d3de88e489bef32503e1546f9055&" },
	{ nome: 'capo', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981021449723994/hood.png?ex=65ec88f6&is=65da13f6&hm=be484141e3d7f60e4ac13bcac4743c48284ca6e5a8acf3f4e7c26924c8e28cc6&" },
	{ nome: 'para-lama', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981019960741948/fender.png?ex=65ec88f6&is=65da13f6&hm=c69cb772176c3ff1e4fa284af7d508e7f4c2a84e432b908d181b8a0f6f8db13e&" },
	{ nome: 'para-lama traseiro', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981020208468108/fenders.png?ex=65ec88f6&is=65da13f6&hm=794c8328dffa0c3fbbd35e158a3eb27cfc7d4f3d65f342d5fb5560efc27fdd50&", id: "right-fender" },
	{ nome: 'teto', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981130002505728/roof.png?ex=65ec8910&is=65da1410&hm=b143321f8a5a2c613f7b373d7970e1ffbbbf968bac11622f91a84c62107404b3&" },
	{ nome: 'motor', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210980955133583360/engine.png?ex=65ec88e6&is=65da13e6&hm=f9ecbe643dfc80c15b03ad62b8ed5a875f249a57deaf55d26036d8fae09ee2f6&" },
	{ nome: 'freios', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210980957272670218/brakes.png?ex=65ec88e7&is=65da13e7&hm=46fc299ce223b03a18ab98220a8f37ec977ef39f1f6c70f2463e9240af8dc10f&" },
	{ nome: 'transmissao', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981264736133151/transmission.png?ex=65ec8930&is=65da1430&hm=3e9cad8e3464291c33bc3e8c25e9b591947bed3dfc96977f52b8fa144506d4c8&", },
	{ nome: 'buzina', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981019193188373/horn.png?ex=65ec88f5&is=65da13f5&hm=4c33a1b985a43d9cee50c5f6c47a56c99f6f44869c1af373fd8d39d35e230a96&" },
	{ nome: 'suspensao', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981263641673788/suspension.png?ex=65ec8930&is=65da1430&hm=0901b55a78cd407b61271e96879beaa1670fb0b47058678aa0f15f79f07afd31&" },
	{ nome: 'blindagem', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210980956425682974/armor.png?ex=65ec88e6&is=65da13e6&hm=535ffc3f6275237f12f50dc96e1446c54241a60fa782150ac747df3ed818453d&" },
	{ nome: 'turbo', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981282750799912/turbo.png?ex=65ec8934&is=65da1434&hm=4c44fdb15c12727ac000efda70a046dcda87e3d20e4596aecb94d35a07bba021&" },
	{ nome: 'interior', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981073408753705/interior.png?ex=65ec8902&is=65da1402&hm=293c6eb69f80eeb0b0e1fd6847488561c1b3a177fbefa96d2cbb08396f9a688f&" },
	{ nome: 'farol', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981282478293022/xenon.png?ex=65ec8934&is=65da1434&hm=ae66657383bfc43ed326ecd1aa0974bb4f8a0b785e24bc4639779920f6cfbe5f&" },
	{ nome: 'decal', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981073702363186/liveries.png?ex=65ec8902&is=65da1402&hm=05aac1397cafb481eb99005b98fe62a4529d03ea4316df3ed849ba3b8fd46a31&" },
	{ nome: 'rodas', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981283614822420/wheels.png?ex=65ec8934&is=65da1434&hm=9f2342e0c0350fadb7542077ddc9679432c3f9e115bcb2b27c2dc9af9386d7d5&" },
	{ nome: 'porta-placa', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981072603717642/Plateholders.png?ex=65ec8902&is=65da1402&hm=654b13147b85b7b5c1c23e8fa4d2a7fa415c98cc74848fef3aa5e5dd906e1acb&", id: "plate-holder" },
	{ nome: 'placa custom', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981283048726618/vanity-plates.png?ex=65ec8934&is=65da1434&hm=9550dcc47954d9bacee03a22e658a4f59f3c3563ed9e51ef2b6b177d90ac1e2a&", id: "vanity-plates" },
	{ nome: 'placa', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981129126023239/plates.png?ex=65ec8910&is=65da1410&hm=0f5bb090bf751b746b12f1307a0fcb754a3edbd2c708abdb7eb09dc2361e8b37&" },
	{ nome: 'neon', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981075032215582/neon.png?ex=65ec8903&is=65da1403&hm=7afbf043465766f8ca8e23e7cb62e35fb046694417aee51fb96fb15de383d160&" },
	{ nome: 'pintura', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981076277657652/paint.png?ex=65ec8903&is=65da1403&hm=b2b2aec9efb5c1d248fe5a1ec2e4fe66c17699c411179827fc5b662112899b32&" },
	{ nome: 'vidro', img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981283849572423/window.png?ex=65ec8935&is=65da1435&hm=ed62bcf8935d5be50d750dca0049a512b95d8503d325edbe8ae75dc5d53526fe&" },
	{ nome: "hidráulica", img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981072943317052/Hydraulics.png?ex=65ec8902&is=65da1402&hm=424393a0e38b87b0d6c8711ae91342f7c272ee4450f8d957216b89d87036c30a&", id: "hydraulics"},
	{ nome: "bloco do motor", img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981019457552434/engine-block.png?ex=65ec88f5&is=65da13f5&hm=b92908f7856dcabeaf89d000be434136a404ec0a5dc8b783ff09e53d098fb852&", id: "engine-block"},
	{ nome: "filtro de ar", img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210980955817512990/air-filter.png?ex=65ec88e6&is=65da13e6&hm=84a87dba062c7fd77280d7cd5c13caa3c9bdda34fcf93ac58fb9130b82a2cd66&", id: "air-filter"},
	{ nome: "suporte", img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981263369052190/struts.png?ex=65ec8930&is=65da1430&hm=07bc3dcd0d74b9c395297d3a13f51b21c8b2f5b4847a77b2a2d76a751d033e76&", id: "struts"},
	{ nome: "antena", img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210980955414863872/aerials.png?ex=65ec88e6&is=65da13e6&hm=ca091542b1081a7350307b1ea117c99bf3199e7db8f9cc0f8794651c149b0ae3&", id: "aerials"},
	{ nome: "design", img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981265092771920/TrimDesign.png?ex=65ec8930&is=65da1430&hm=a91825a7da2ab47e9d6d80a21945043d3818b83e6b792445252d23c0e0515097&", id: "trim"},
	{ nome: "tanque", img: "https://cdn.discordapp.com/attachments/1210980551800918086/1210981264354582599/tank.png?ex=65ec8930&is=65da1430&hm=d072055008cf5fee9e9e537087bc61f5f5b1e2f13b8b257e4e958c5c9c86012b&", id: "tank"},
	{ nome: "adesivo", img: "https://cdn.discordapp.com/attachments/824502347732353055/853762370375254046/adesivo.png?ex=65e4f92b&is=65d2842b&hm=e2e4825996e2803b597fc170c1e86a541756752d450fe4f42c9f1f7721d00375&", id: "sticker"},
	{ nome: "extras", img: "https://cdn.discordapp.com/attachments/970224145336008714/1060007467016265839/add-xxl.png?ex=65e7c762&is=65d55262&hm=c8b929e68fb11a622c6ace5af2978ad0f27a862d1783aef1f1cba987be8802e8&", id: "extras"},
	{ nome: "lightbar", img: "https://cdn.discordapp.com/attachments/970224145336008714/1060706226528338061/lightbar.png?ex=65ea5227&is=65d7dd27&hm=7dd62abee23f0eb496f9285f3be38e3e81c2d7f7f35a358f47440375f71bf49e&", id: "lightbar"},
];



let chassis = [
	{ nome: "capa do farol", img: "https://nation-resources.me/images/nation_bennys/arch-cover.png", id: "arch-cover"},
	{ nome: "portas", img: "https://nation-resources.me/images/nation_bennys/doors.png", id: "doors"},
	{ nome: "gaiola", img: "https://nation-resources.me/images/nation_bennys/roll-cage.png", id: "roll-cage"},
]

let interior = [
	{ nome: "enfeites", img: "https://nation-resources.me/images/nation_bennys/ornaments.png", id: "ornaments" },
	{ nome: "painel", img: "https://nation-resources.me/images/nation_bennys/dashboard.png", id: "dashboard" },
	{ nome: "ponteiros", img: "https://nation-resources.me/images/nation_bennys/dials.png", id: "dials" },
	{ nome: "janela", img: "https://nation-resources.me/images/nation_bennys/janela.png", id: "janela"},
	{ nome: "bancos", img: "https://nation-resources.me/images/nation_bennys/seats.png", id: "seats"},
	{ nome: "placas", img: "https://nation-resources.me/images/nation_bennys/plaques.png", id: "plaques"},
	{ nome: "design", img: "https://nation-resources.me/images/nation_bennys/trim-design.png", id: "trim-design"},
	{ nome: "volante", img: "https://nation-resources.me/images/nation_bennys/steering-wheel.png", id: "steering-wheel"},
	{ nome: "câmbio", img: "https://nation-resources.me/images/nation_bennys/shift-lever.png", id: "shift-lever"},
	{ nome: "som", img: "https://nation-resources.me/images/nation_bennys/speaker.png", id: "speaker"},
	{ nome: "porta-malas", img: "https://nation-resources.me/images/nation_bennys/trunk.png", id: "trunk"},
	
]

let wheels = [
	{ nome: "tipo", img: "https://nation-resources.me/images/nation_bennys/wheel-types.png", id: "wheel-types" },
	{ nome: "cor", img: "https://nation-resources.me/images/nation_bennys/wheel-colors.png", id: "wheel-colors"},
	{ nome: "acessórios", img: "https://nation-resources.me/images/nation_bennys/wheel-accessories.png", id: "wheel-accessories"},
]

let wheeltypes = [
	{ nome:  "padrão", img: "https://nation-resources.me/images/nation_bennys/padrão.png"},
	{ nome:  "sport", img: "https://nation-resources.me/images/nation_bennys/sport.png"},
	{ nome:  "muscle", img: "https://nation-resources.me/images/nation_bennys/muscle.png"},
	{ nome:  "lowrider", img: "https://nation-resources.me/images/nation_bennys/lowrider.png"},
	{ nome:  "suv", img: "https://nation-resources.me/images/nation_bennys/suv.png"},
	{ nome:  "offroad", img: "https://nation-resources.me/images/nation_bennys/offroad.png"},
	{ nome:  "tuner", img: "https://nation-resources.me/images/nation_bennys/tuner.png"},
	{ nome:  "highend", img: "https://nation-resources.me/images/nation_bennys/highend.png"},
	{ nome:  "bennys", img: "https://nation-resources.me/images/nation_bennys/bennys.png"},
	{ nome:  "bespoke", img: "https://nation-resources.me/images/nation_bennys/bespoke.png"},
	{ nome:  "open", img: "https://nation-resources.me/images/nation_bennys/open.png"},
	{ nome:  "street", img: "https://nation-resources.me/images/nation_bennys/street.png"},
	{ nome:  "track", img: "https://nation-resources.me/images/nation_bennys/track.png"},
	{ nome:  "dianteira", img: "https://nation-resources.me/images/nation_bennys/dianteira.png"},
	{ nome:  "traseira", img: "https://nation-resources.me/images/nation_bennys/traseira.png"},
]


let colortypes = [
	{ type: "cromado" },
	{ type: "fosco" },
	{ type: "metalico" },
	{ type: "metal" }
]

let pneus = [
	"fabrica", "custom", "drift", "bulletproof", "smoke"
]

let oldOptions = opcoes;
let oldPenus = pneus;


const getTitle = (t) => {
	let titulo = t;
	for (k in lang) {
		let v = lang[k];
		if (typeof(v) == "object") {
			for (i in v) {
				let obj = v[i].id;
				if (obj && titulo == obj) {
					return v[i].name;
				}
			}

		}
	}
	return titulo
}


const hasTypeOfMods = (type) => {
	for (k in type) {
		let mod = type[k].id; if (!mod) { mod = type[k].nome }
		if (vehicle[mod] != undefined && typeof(vehicle[mod]) == "object" && vehicle[mod][0] > 1) {
			return true;
		}
	}
	return false
}


function showMenu(menu,titulo) {
	$.post("https://"+resourceName+"/cam", JSON.stringify( {
			cam : menu
	}))
	$("#menu").slideUp(500, function(){
		buildMenu(menu,getTitle(titulo));
	});
}
function buildMenu(menu,titulo) {
	$("#titulo").html(titulo);
	$("#menu").html("");
	$("#menu").attr("data-action", menu);
	if (menu != "mainMenu") {
		$("#pagar").slideUp(500);
		$("#voltar").show();
		$("#sair").hide();
	}
	else {
		if (canbuy) {
			$("#pagar").slideDown(500);
		}
		$("#sair").show();
		$("#voltar").hide();
	}
	let nome = titulo;
	let img = "";
	let option = getOpcao(menu);
	let selected = undefined;
	let customselected = undefined;
	if (option) {
		nome = option.nome;
		img = option.img;
	}
	switch(menu) {
		case "mainMenu":
			for (let i = 0; i < opcoes.length; i++) {
				let id = opcoes[i].nome;
				if (opcoes[i].id) {
					id = opcoes[i].id;
				}
				if (id === "neon" && vehicle["bike"]) {
					continue;
				}


				if (id != "rodas" && id != "pintura" && id != "interior" && id != "chassi" && vehicle[id] != undefined && typeof(vehicle[id] == "object") && vehicle[id][0] < 2) {
					continue;
				} else if (id == "interior" && !hasTypeOfMods(interior)) { continue; } else if (id == "chassi" && !hasTypeOfMods(chassis)) { continue; 
				} else if (id == "extras" && Object.keys(vehicle[id]).length == 0) { continue; } 

				
				$("#menu").append(
					"<button id='"+id+"' class='option'>"+
						"<img src='"+opcoes[i].img+"'>"+
						"<div class='textbox'><span>"+getTitle(opcoes[i].nome)+"</span></div>"+
					"</button>"
				);
		
				$("#"+id).click(function(e){
					showMenu(id,opcoes[i].nome);
				});

			}
		break;
		
		case "chassi":
			for (let i = 0; i < chassis.length; i++) {
				let id = chassis[i].id;

				if (vehicle[id][0] < 2) { continue; }

				$("#menu").append(
					"<button id='"+id+"' class='option'>"+
						"<img src='"+chassis[i].img+"'>"+
						"<div class='textbox'><span>"+getTitle(chassis[i].nome)+"</span></div>"+
					"</button>"
				);
		
				$("#"+id).click(function(e){
					showMenu(id,chassis[i].nome);
					$("#voltar").attr("data-action", "chassi");
				});
			}
		break;
		
		case "interior":
			for (let i = 0; i < interior.length; i++) {
				let id = interior[i].id;

				if (vehicle[id][0] < 2) { continue; }

				$("#menu").append(
					"<button id='"+id+"' class='option'>"+
						"<img src='"+interior[i].img+"'>"+
						"<div class='textbox'><span>"+getTitle(interior[i].nome)+"</span></div>"+
					"</button>"
				);
		
				$("#"+id).click(function(e){
					showMenu(id,interior[i].nome);
					$("#voltar").attr("data-action", "interior");
				});
			}
		break;
		
		case "rodas":
			for (let i = 0; i < wheels.length; i++) {
				let id = wheels[i].id;
				$("#menu").append(
					"<button id='"+id+"' class='option'>"+
						"<img src='"+wheels[i].img+"'>"+
						"<div class='textbox'><span>"+getTitle(wheels[i].nome)+"</span></div>"+
					"</button>"
				);
		
				$("#"+id).click(function(e){
					showMenu(id,wheels[i].nome);
					$("#voltar").attr("data-action", "rodas");
				});
			}
		break;
		
		case "wheel-types":
			let moto = vehicle["bike"];
			for (let i = 0; i < wheeltypes.length; i++) {
				let id = wheeltypes[i].nome;

				if (id === "traseira" || id === "dianteira") {
					if (moto) {
						$("#menu").append(
						"<button id='"+id+"' class='option'>"+
							"<img src='"+wheeltypes[i].img+"'>"+
							"<div class='textbox'><span>"+getTitle(wheeltypes[i].nome)+"</span></div>"+
						"</button>"
						);
					}
				} else if (!moto) {
					$("#menu").append(
						"<button id='"+id+"' class='option'>"+
							"<img src='"+wheeltypes[i].img+"'>"+
							"<div class='textbox'><span>"+getTitle(wheeltypes[i].nome)+"</span></div>"+
						"</button>"
					);	
				}	
				
				$("#"+id).click(function(e){
					if (id != "padrão") {
						showMenu(id,wheeltypes[i].nome);
						$("#voltar").attr("data-action", "wheel-types");
					} else {
						resetWheelType();
						$.post("https://"+resourceName+"/callbacks", JSON.stringify({
							type: "stock"
						}));
					}
				});
			}
		break;
		
		case "wheel-accessories":
			for (let i in pneus) {
				let v = pneus[i];
				let id = v+"-pneus";
				if (v == "smoke") id = v+"-colors";
				let enabled = v != "smoke" && vehicle[id];
				$("#menu").append(
					`<button id='${id}' class='option2${enabled ? " option2-focus" : ""}'>
						<img src='${img}'>
						<div class='textbox' style='padding: 15px 0;'><span style='color: rgb(0, 137, 250);'>${getTitle(v)}</span></div>
					</button>`
				);
				$("#"+id).click(function(e) {
					if (v == "smoke") {
						showMenu('smoke-colors','fumaça');
						$("#voltar").attr("data-action", "wheel-accessories");
					} else if (v == "fabrica") {
						$("button").removeClass("option2-focus");
						$(this).toggleClass("option2-focus");
						vehicle[id] = true;
						vehicle["custom-pneus"] = false;
						vehicle["bulletproof-pneus"] = false;
						vehicle["drift-pneus"] = false;
						$.post("https://"+resourceName+"/callbacks", JSON.stringify({type: this.id}));

					} else {
						vehicle[id] = !vehicle[id];
						vehicle["fabrica-pneus"] = false;
						$(this).toggleClass("option2-focus");
						if (vehicle[id])
							$("#fabrica-pneus").removeClass("option2-focus");
						$.post("https://"+resourceName+"/callbacks", JSON.stringify({type: this.id}));
					}
					$("button").blur();
				});
			}
		break;
		
		case "wheel-colors":
			$("#menu").append(
				"<div id='other-colors' class='other-colors' style='margin-top: 100px;'>"+
					"<div style='position: relative; font-size: 30px; color: white; margin-bottom: 30px; text-align: center; z-index: 50;'><span>"+getTitle('selecionar cor')+"</span></div>"+
					"<div id='color-selector' class='color-selector2' style='font-size: 50px;'><button id='wheelcolor-back' class='arrow2' data-action='0'><i class='fas fa-arrow-left'></i></button><i class='fas fa-palette'></i><button id='wheelcolor-up' class='arrow2' data-action='0'><i class='fas fa-arrow-right'></i></button></div>"+
				"</div>"
			);

			$("#wheelcolor-up").click(function(e) {
				let limit = 74;
				let action = parseInt($(this).attr("data-action"));
				action += 1;
				if (action > limit)
					action = 0;
				$(this).attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: "wheelcolor-"+(action+1)
				}));
			});

			$("#wheelcolor-back").click(function(e) {
				let limit = 74;
				let action = parseInt($("#wheelcolor-up").attr("data-action"));
				action -= 1;
				if (action < -1)
					action = limit;
				$("#wheelcolor-up").attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: "wheelcolor-"+(action+1)
				}));
			});
		break;

		case "smoke-colors":
			$("#menu").append(
				`<label class='color-picker'><input id='smoke-colors' class='hide' type='color' oninput="changeColor('smoke-colors')"/>`+
					"<div class='color' style='background: linear-gradient(0deg, rgba(0,0,0,.3) 0%, #ff0000 50%, rgba(0,0,0,.3) 100%);'></div>"+
				"<div style='position: relative; top: 110px; font-size: 30px; color: white;'><span>"+getTitle('cor da fumaça')+"</span></div></label>"
			);

			if (vehicle[menu]) {
				let style = "linear-gradient(0deg, rgba(0,0,0,.3) 0%, "+vehicle[menu]+" 50%, rgba(0,0,0,.3) 100%)";
				$('.color').css('background',style);
			}
		break;

		case "xenon-colors":
			$("#menu").append(
				"<div id='other-colors' class='other-colors' style='margin-top: 100px;'>"+
					"<div style='position: relative; font-size: 30px; color: white; margin-bottom: 30px; text-align: center; z-index: 50;'><span>"+getTitle('selecionar cor')+"</span></div>"+
					"<div id='color-selector' class='color-selector2' style='font-size: 50px;'><button id='xenon-colors-back' class='arrow2' data-action='0'><i class='fas fa-arrow-left'></i></button><i class='fas fa-palette'></i><button id='xenon-colors-up' class='arrow2' data-action='-1'><i class='fas fa-arrow-right'></i></button></div>"+
				"</div>"
			);

			$("#xenon-colors-up").click(function(e) {
				let limit = 12;
				let action = parseInt($(this).attr("data-action"));
				action += 1;
				if (action > limit)
					action = 0;
				$(this).attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: "xenon-colors-"+action
				}));
			});

			$("#xenon-colors-back").click(function(e) {
				let limit = 12;
				let action = parseInt($("#xenon-colors-up").attr("data-action"));
				action -= 1;
				if (action < 0)
					action = limit;
				$("#xenon-colors-up").attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: "xenon-colors-"+action
				}));
			});
		break;

		case "neon-colors":
			$("#menu").append(
				`<label class='color-picker'><input id='neon-colors' class='hide' type='color' oninput="changeColor('neon-colors')"/>`+
					"<div class='color' style='background: linear-gradient(0deg, rgba(0,0,0,.3) 0%, #ff0000 50%, rgba(0,0,0,.3) 100%);'></div>"+
				"<div style='position: relative; top: 110px; font-size: 30px; color: white;'><span>"+getTitle('cor do neon')+"</span></div></label>"
			);

			if (vehicle[menu]) {
				let style = "linear-gradient(0deg, rgba(0,0,0,.3) 0%, "+vehicle[menu]+" 50%, rgba(0,0,0,.3) 100%)";
				$('.color').css('background',style);
			}
		break;

		case "cor-primaria":
			$("#menu").append(
				`<label class='color-picker' style='top: 100px;'><input id='cor-primaria' class='hide' type='color' oninput="changeColor('cor-primaria')"/>`+
					"<div class='color' style='background: linear-gradient(0deg, rgba(0,0,0,.3) 0%, #ff0000 50%, rgba(0,0,0,.3) 100%);'></div>"+
				"<div style='position: relative; bottom: 80px; font-size: 30px; color: white;'><span>"+getTitle('selecionar cor')+"</span></div></label>"+
				"<div id='other-colors' class='other-colors'>"+
					"<div style='position: relative; font-size: 25px; color: white; margin: auto; text-align: center; z-index: 50;'><span>"+getTitle('tipos')+"</span></div>"+
					"<div id='color-selector' class='color-selector'><button id='cor-primaria-back' class='arrow' data-action='0'><i class='fas fa-arrow-left'></i></button><i class='fas fa-palette'></i><button id='cor-primaria-up' class='arrow' data-action='0'><i class='fas fa-arrow-right'></i></button></div>"+
				"</div>"
			);
			for (let i = 0; i < colortypes.length; i++) {
				let id = "cor-primaria-"+colortypes[i].type;
				let texto = colortypes[i].type;
				$(".other-colors").append(
					"<button id='"+id+"' class='colortype'>"+getTitle(texto)+"</button>"
				)
				$("#"+id).click(function(e) {
					$("#color-selector").show();
					$("#cor-primaria-up").attr("data-action",0);
					$.post("https://"+resourceName+"/callbacks", JSON.stringify({
						type: id+"-"+(parseInt($("#cor-primaria-up").attr("data-action"))+1)
					}));
					$("#pagar").attr("data-action", id);
				});
			}


			$("#other-colors").append(
				"<div style='position: relative; font-size: 25px; color: white; margin-top: 10px; text-align: center;'><span>"+getTitle('perolado')+"</span></div>"+
				"<div id='color-selector2' class='color-selector2'><button id='cor-perolado-back' class='arrow' data-action='-1'><i class='fas fa-arrow-left'></i></button><i class='fas fa-palette'></i><button id='cor-perolado-up' class='arrow' data-action='-1'><i class='fas fa-arrow-right'></i></button></div>"
			)

			$("#cor-primaria-up").click(function(e) {
				let type = $("#pagar").attr("data-action");
				let action = parseInt($(this).attr("data-action"));
				let index = "cromado"
				switch(type) {
					case "cor-primaria-metalico":
						index = "metalico"
					break;
					case "cor-primaria-fosco":
						index = "fosco"
					break;
					case "cor-primaria-metal":
						index = "metal"
					break;
				}
				action++;
				if (action >= vehicle.colors[index].length)
					action = 0;
				$(this).attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: type+"-"+(action+1)
				}));
			});

			$("#cor-primaria-back").click(function(e) {
				let type = $("#pagar").attr("data-action");
				let action = parseInt($("#cor-primaria-up").attr("data-action"));
				let index = "cromado"
				switch(type) {
					case "cor-primaria-metalico":
						index = "metalico"
					break;
					case "cor-primaria-fosco":
						index = "fosco"
					break;
					case "cor-primaria-metal":
						index = "metal"
					break;
				}
				action--;
				if (action < 0)
					action = vehicle.colors[index].length-1;
				$("#cor-primaria-up").attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: type+"-"+(action+1)
				}));
			});


			$("#cor-perolado-up").click(function(e) {
				let type = "cor-perolado";
				let limit = 241;
				let action = parseInt($(this).attr("data-action"));
				action += 1;
				if (action > limit)
					action = 0;
				$(this).attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: type+"-"+(action+1)
				}));
			});

			$("#cor-perolado-back").click(function(e) {
				let type = "cor-perolado";
				let limit = 241;
				let action = parseInt($("#cor-perolado-up").attr("data-action"));
				action -= 1;
				if (action < -1)
					action = limit;
				$("#cor-perolado-up").attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: type+"-"+(action+1)
				}));
			});

			if (vehicle[menu]) {
				let style = "linear-gradient(0deg, rgba(0,0,0,.3) 0%, "+vehicle[menu]+" 50%, rgba(0,0,0,.3) 100%)";
				$('.color').css('background',style);
			}

		break;

		case "cor-secundaria":
			$("#menu").append(
				`<label class='color-picker' style='top: 100px;'><input id='cor-secundaria' class='hide' type='color' oninput="changeColor('cor-secundaria')"/>`+
					"<div class='color' style='background:#000000;'></div>"+
				"<div style='position: relative; bottom: 80px; font-size: 30px; color: white;'><span>"+getTitle('selecionar cor')+"</span></div></label>"+
				"<div id='other-colors' class='other-colors' style='margin-top: 190px;'>"+
					"<div style='position: relative; font-size: 25px; color: white; margin: auto; text-align: center; z-index: 50;'><span>"+getTitle('tipos')+"</span></div>"+
					"<div id='color-selector' class='color-selector'><button id='cor-secundaria-back' class='arrow' data-action='0'><i class='fas fa-arrow-left'></i></button><i class='fas fa-palette'></i><button id='cor-secundaria-up' class='arrow' data-action='0'><i class='fas fa-arrow-right'></i></button></div>"+
				"</div>"
			);
			for (let i = 0; i < colortypes.length; i++) {
				let id = "cor-secundaria-"+colortypes[i].type;
				let texto = colortypes[i].type;
				$(".other-colors").append(
					"<button id='"+id+"' class='colortype'>"+getTitle(texto)+"</button>"
				)
				$("#"+id).click(function(e) {
					$("#color-selector").show();
					$("#cor-secundaria-up").attr("data-action",0);
					$.post("https://"+resourceName+"/callbacks", JSON.stringify({
						type: id+"-"+(parseInt($("#cor-secundaria-up").attr("data-action"))+1)
					}));
					$("#pagar").attr("data-action", id);
				});
			}

			$("#cor-secundaria-up").click(function(e) {
				let type = $("#pagar").attr("data-action");
				let action = parseInt($(this).attr("data-action"));
				let index = "cromado"
				switch(type) {
					case "cor-secundaria-metalico":
						index = "metalico"
					break;
					case "cor-secundaria-fosco":
						index = "fosco"
					break;
					case "cor-secundaria-metal":
						index = "metal"
					break;
				}
				action++;
				if (action > vehicle.colors[index].length)
					action = 0;
				$(this).attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: type+"-"+(action+1)
				}));
			});

			$("#cor-secundaria-back").click(function(e) {
				let type = $("#pagar").attr("data-action");
				let action = parseInt($("#cor-secundaria-up").attr("data-action"));
				let index = "cromado"
				switch(type) {
					case "cor-secundaria-metalico":
						index = "metalico"
					break;
					case "cor-secundaria-fosco":
						index = "fosco"
					break;
					case "cor-secundaria-metal":
						index = "metal"
					break;
				}
				action--;
				if (action < 0)
					action = vehicle.colors[index].length-1;
				$("#cor-secundaria-up").attr("data-action",action);
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: type+"-"+(action+1)
				}));
			});


			if (vehicle[menu]) {
				let style = "linear-gradient(0deg, rgba(0,0,0,.3) 0%, "+vehicle[menu]+" 50%, rgba(0,0,0,.3) 100%)";
				$('.color').css('background',style);
			}

		break;

		case "blindagem":
			let blin = 0
			for (let i = 0; i < 6; i++) {
				let texto = blin+"%";
				let id = "blindagem-"+i;
				if  (blin === 0)
					texto = lang.default;
				$("#menu").append(
					"<button id='"+id+"' class='option2'>"+
					"<img src='"+img+"'>"+
					"<span>"+getTitle(texto)+"</span>"+
					"</button>"
				);

				$("#"+id).click(function(e) {
					vehicle[menu][1] = i-1;
					$.post("https://"+resourceName+"/callbacks", JSON.stringify({
						type: this.id,
						blindagem: i-1
					}));
				});
				
				blin += 20;
			}

			if (vehicle[menu]) {
				selected = vehicle[menu][1]+1;
			} else {
				selected = 0;
			}
		break;

		case "motor": case "freios": case "transmissao": 
			let limit = 0;
			if (vehicle[menu])
				limit = vehicle[menu][0];
			for (let i = 0; i < limit; i++) {
				let id = menu+"-"+i;
				let texto = lang.level+i;
				if (i === 0)
					texto = lang.default;
				$("#menu").append(
					"<button id='"+id+"' class='option2'>"+
					"<img src='"+img+"'>"+
					"<span>"+getTitle(texto)+"</span>"+
					"</button>"
				);

				$("#"+id).click(function(e) {
					vehicle[menu][1] = i-1;
					$.post("https://"+resourceName+"/callbacks", JSON.stringify({
						type: this.id
					}));
				});
			}
			
			if (vehicle[menu]) {
				selected = vehicle[menu][1]+1;
			} else {
				selected = 0;
			}
		break;


		case "turbo":  
			for (let i = 0; i < 2; i++) {
				let id = "turbo-"+i;
				let texto = "turbo";
				if (i === 0)
					texto = lang.default;
				$("#menu").append(
					"<button id='"+id+"' class='option2'>"+
					"<img src='"+img+"'>"+
					"<span>"+getTitle(texto)+"</span>"+
					"</button>"
				);

				$("#"+id).click(function(e) {
					vehicle[menu] = i;
					$.post("https://"+resourceName+"/callbacks", JSON.stringify({
						type: this.id
					}));
				});
			}

			if (vehicle[menu]) {
				selected = 1;
			} else {
				selected = 0;
			}
		break;


		case "farol":
			$("#menu").append(
				"<button id='farol-fabrica' class='option2'>"+
					"<img src='"+img+"'>"+
					"<div class='textbox' style='padding: 15px 0;'><span style='color: rgba(0, 132, 141, 0.781);'>"+getTitle('fabrica')+"</span></div>"+
				"</button>"+
				"<button id='farol-xenon' class='option2'>"+
					"<img src='"+img+"'>"+
					"<div class='textbox' style='padding: 15px 0;'><span style='color: rgba(0, 132, 141, 0.781);'>"+getTitle('xenon')+"</span></div>"+
				"</button>"+
				"<button id='xenon-colors' class='option2'>"+
					"<img src='"+img+"'>"+
					"<div class='textbox' style='padding: 15px 0;'><span style='color: rgba(0, 132, 141, 0.781);'>"+getTitle('cor')+"</span></div>"+
				"</button>"
			);

			$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: "farol"
			}));

			$("#farol-fabrica").click(function(e) {
				vehicle[menu] = false;
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: this.id
				}));
			});

			$("#farol-xenon").click(function(e) {
				vehicle[menu] = true;
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: this.id
				}));
			});

			$("#xenon-colors").click(function(e) {
				showMenu('xenon-colors','cor xenon');
				$("#voltar").attr("data-action", "farol");
			});

			
			if (vehicle[menu]) {
				selected = "xenon";
			} else {
				selected = "fabrica";
			}

		break;

		case "neon":
			$("#menu").append(
				"<button id='neon-default' class='option2'>"+
					"<img src='"+img+"'>"+
					"<div class='textbox' style='padding: 15px 0;'><span style='color: rgba(0, 132, 141, 0.781);'>"+lang.default+"</span></div>"+
				"</button>"+
				"<button id='neon-kit' class='option2'>"+
					"<img src='"+img+"'>"+
					"<div class='textbox' style='padding: 15px 0;'><span style='color: rgba(0, 132, 141, 0.781);'>"+getTitle('kit neon')+"</span></div>"+
				"</button>"+
				"<button id='neon-colors' class='option2'>"+
					"<img src='"+img+"'>"+
					"<div class='textbox' style='padding: 15px 0;'><span style='color: rgba(0, 132, 141, 0.781);'>"+getTitle('cores neon')+"</span></div>"+
				"</button>"
			);

			$("#neon-default").click(function(e) {
				vehicle[menu] = false
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: this.id
				}));
			});

			$("#neon-kit").click(function(e) {
				vehicle[menu] = true
				$.post("https://"+resourceName+"/callbacks", JSON.stringify({
					type: this.id
				}));
			});

			$("#neon-colors").click(function(e) {
				showMenu('neon-colors','cores neon');
				$("#voltar").attr("data-action", "neon");
			});

			if (vehicle[menu]) {
				selected = "kit";
			} else {
				selected = "default";
			}

		break;

		case "pintura":
			$("#menu").append(
				"<button id='cor-primaria' class='option2'>"+
					"<img src='"+img+"'>"+
					"<div class='textbox' style='padding: 15px 0;'><span style='color: rgba(0, 132, 141, 0.781);'>"+getTitle('primária')+"</span></div>"+
				"</button>"+
				"<button id='cor-secundaria' class='option2'>"+
					"<img src='"+img+"'>"+
					"<div class='textbox' style='padding: 15px 0;'><span style='color: rgba(0, 132, 141, 0.781); letter-spacing: 0;'>"+getTitle('secundária')+"</span></div>"+
				"</button>"
			);

			$("#cor-primaria").click(function(e) {
				showMenu('cor-primaria','cor primária');
				$("#voltar").attr("data-action", "pintura");
			});

			$("#cor-secundaria").click(function(e) {
				showMenu('cor-secundaria','cor secundária');
				$("#voltar").attr("data-action", "pintura");
			});
		break;

		case "extras":
			selected = undefined;
			for (let i = 0; i <= 14; i++) {
				if (vehicle[menu][i] == undefined)
					continue;
				let id = nome +"-"+ i;
				if (option.id)
					id = option.id + "-"+i;
				$("#menu").append(
					`<button id='${id}' class='${"option2" + (vehicle[menu][i] ? " option2-focus" : "")}'>
					<img src='${img}'>
					<span>${i}</span>
					</button>`
				);

				$("#"+id).click(function(e) {
					$.post("https://"+resourceName+"/callbacks", JSON.stringify({type: id}),(extras)=>{
						vehicle[menu] = extras;
						$(".option2-focus").removeClass("option2-focus");
						for (let j = 0; j <= 14; j++) {
							if (vehicle[menu][j] == undefined)
								continue;
							let el = $("#"+nome+"-"+j);
							if (vehicle[menu][j])
								el.addClass("option2-focus");
							else
								el.removeClass("option2-focus");
						}
					});
					$("button").blur();
				});

			}
		break;

		default:
			let limite = 1;

			if (vehicle[menu] != undefined && vehicle[menu].length > 0) {
				limite = vehicle[menu][0];
				selected = vehicle[menu][1]+1;
			}
			
			switch(menu) {
				case "sport": case "tuner": case "muscle": case "lowrider": case "suv": case "offroad": case "highend": case "bennys": case "bespoke": case "open": case "street": case "track":
					limite = vehicle[menu][2] + 1;
					if (!vehicle[menu][0])
						selected = undefined;
				break;
				case "sticker": 
					if (limite > -1) limite++;
					selected--;
				break;
			}
			for (let i = 0; i < limite; i++) {
				let id = nome +"-"+ i;
				if (option.id)
					id = option.id + "-"+i;
				let index = i;
				if (i === 0)
					index = lang.default;
				$("#menu").append(
					"<button id='"+id+"' class='option2'>"+
					"<img src='"+img+"'>"+
					"<span>"+index+"</span>"+
					"</button>"
				);

				$("#"+id).click(function(e) {
					$.post("https://"+resourceName+"/callbacks", JSON.stringify({
						type: id
					}));
					if (selected != undefined) {
						vehicle[menu][1] = i-1;
					} else if (getWheelType(menu)) {
						resetWheelType();
						vehicle[menu][0] = true;
						vehicle[menu][1] = i-1;
					}
				});

			}

	}
	$("#menu").slideDown(500,function(){
		document.querySelector("#menu").scrollTo({top: 0, behavior: 'smooth'});
		if (selected != undefined) {
			if (customselected != undefined) {
				$("#"+selected).focus();
			} else {
				$("#"+menu+"-"+selected).focus();
			}
		}
	});
	$(".menu button").mouseenter(function () {
		audioPlayer = new Audio("sounds/click.ogg");
		audioPlayer.volume = 0.01;
		let playPromise = audioPlayer.play();

		if (playPromise !== undefined) {
		  playPromise.then(_ => {
		  })
		  .catch(error => {
		  });
		}
	});
	$(".menu button").click(function () {
		audioPlayer2 = new Audio("sounds/MouseClickFast.wav");
		audioPlayer2.volume = 0.01;
		let playPromise2 = audioPlayer2.play();
		if (playPromise2 !== undefined) {
			playPromise2.then(_ => {
			})
			.catch(error => {
			});
		}
	});
}

$("button").mouseenter(function () {
	audioPlayer = new Audio("sounds/click.ogg");
	audioPlayer.volume = 0.01;
	let playPromise = audioPlayer.play();

	if (playPromise !== undefined) {
	  playPromise.then(_ => {
	  })
	  .catch(error => {
	  });
	}
});
$("button").click(function () {
	audioPlayer2 = new Audio("sounds/MouseClickFast.wav");
	audioPlayer2.volume = 0.01;
	let playPromise2 = audioPlayer2.play();
	if (playPromise2 !== undefined) {
		playPromise2.then(_ => {
		})
		.catch(error => {
		});
	}
});

function getWheelType(type) {
	for (i = 0; i < wheeltypes.length; i++) {
		if (wheeltypes[i].nome === type)
			return wheeltypes[i];
	}
	return false;
}

function resetWheelType() {
	for (i = 0; i < wheeltypes.length; i++) {
		if (vehicle[wheeltypes[i].nome] && wheeltypes[i].nome != "traseira") {
			vehicle[wheeltypes[i].nome][0] = false;
		}
	}
	return false;
}


function changeColor(id) {
	let color = $("#"+id).val();
	$('.color-code').html(color);
	let style = "linear-gradient(0deg, rgba(0,0,0,.3) 0%, "+color+" 50%, rgba(0,0,0,.3) 100%)";
	$('.color').css('background',style);
	$.post("https://"+resourceName+"/callbacks", JSON.stringify({
		type: id,
		color: toRGB(color)
	}));
	vehicle[id] = color;
}


function toRGB(value) {
	let rgb = value.match(/[A-Za-z0-9]{2}/g).map(function(v) { return parseInt(v, 16) }).join(",");
	return rgb;
}



function getOpcao(id) {
	for (let i = 0; i < opcoes.length; i++) {
		if (opcoes[i].id && opcoes[i].id === id)
			return opcoes[i]
		else if (opcoes[i].nome === id)
			return opcoes[i]
	}
	for (let i = 0; i < chassis.length; i++) {
		if (chassis[i].id === id)
			return chassis[i]
	}
	for (let i = 0; i < interior.length; i++) {
		if (interior[i].id === id)
			return interior[i]
	}
	for (let i = 0; i < wheels.length; i++) {
		if (wheels[i].id === id)
			return wheels[i]
	}
	for (let i = 0; i < wheeltypes.length; i++) {
		if (wheeltypes[i].nome === id)
			return wheeltypes[i]
	}
}



$('#voltar').click(function(e){
	let menu = $("#voltar").attr("data-action");
	let title = menu;
	switch (title) {
		case "mainMenu":
			title = Bennys;
		break;
		case "wheel-types":
			title = "tipo";
		break;
		case "wheel-accessories":
			title = "acessórios";
		break;
	}
	showMenu(menu,title);
	switch (menu) {
		case "wheel-types": case "wheel-accessories":
			menu = "rodas";
		break;
		default:
			menu = "mainMenu";
	}
	$("#voltar").attr("data-action", menu);
	$.post("https://"+resourceName+"/voltar");
});

$('#sair').click(function(e){
	$.post("https://"+resourceName+"/close");
});

$('#pagar').click(function(e){
	if ($('#pagar').attr("data-action")) {
		let data = $('#pagar').attr("data-action");
		$.post("https://"+resourceName+"/pagar");
	}
});

$('#reparar').click(function(e){
	$.post("https://"+resourceName+"/callbacks", JSON.stringify( {
		type : "reparar"
	}))
});

