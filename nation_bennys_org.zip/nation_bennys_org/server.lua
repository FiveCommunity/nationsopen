serverScript = true
local Tunnel = Tunnel or module("vrp","lib/Tunnel")
local Proxy = Proxy or module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP")
func = {}
Tunnel.bindInterface("nation_bennys",func)
Proxy.addInterface("nation_bennys",func)
fclient = Tunnel.getInterface("nation_bennys")

local vehicleTyres = GlobalState.vehicleTyres or {}
GlobalState.vehicleTyres = vehicleTyres

CreateThread(function()
    for _,veh in pairs(GetAllVehicles()) do
        if (Entity(veh).state or {}).inBennys then
            Entity(veh).state.inBennys = nil
            FreezeEntityPosition(veh,false)
        end
    end
end)

function func.checkPermission(perm)
    local source = source
    local user_id = vRP.getUserId(source)
    local perm = perm or config.permissao
    if not perm then return true end
    if type(perm) == "table" then
        for i, p in pairs(perm) do
            if vRP.hasPermission(user_id, p) then
                return true
            end
        end
    elseif vRP.hasPermission(user_id,perm) then
        return true
    end
    if config.servermsg then
        TriggerClientEvent("Notify",source,"negado",config.servermsg[1],5000)
    else
        TriggerClientEvent("Notify",source,"negado","Você não tem permissão",5000)
    end
    return false
end

function func.checkMotoPermission()
    local source = source
    local user_id = vRP.getUserId(source)
    if config.moto_permission then
        if vRP.hasPermission(user_id,config.moto_permission) then
            return true
        end
    else
        return true
    end
    if config.servermsg then
        TriggerClientEvent("Notify",source,"negado",config.servermsg[1],5000)
    else
        TriggerClientEvent("Notify",source,"negado","Você não tem permissão",5000)
    end
    return false
end


function func.checkVehicle(vehicle)
    local source = source
    local user_id = vRP.getUserId(source)
    local veh = NetworkGetEntityFromNetworkId(vehicle)
    if DoesEntityExist(veh) then 
        local state = Entity(veh).state
        if state.inBennys then
            if config.servermsg then
                TriggerClientEvent("Notify",source,"negado",config.servermsg[2],5000)
            else
                TriggerClientEvent("Notify",source,"negado","Veículo já está sendo modificado por outro mecânico.",5000)
            end
            return false
        else
            state.inBennys = source
            FreezeEntityPosition(veh,true)
            return true
        end
    end
    return true
end

function format(n)
	local left,num,right = string.match(n,[[^([^%d]*%d)(%d*)(.-)$]])
	return left..(num:reverse():gsub('(%d%d%d)','%1.'):reverse())..right
end

function func.removeVehicle(vehicle)
    local veh = NetworkGetEntityFromNetworkId(vehicle)
    if DoesEntityExist(veh) then 
        FreezeEntityPosition(veh,false)
    end
    Wait(2500)
    if DoesEntityExist(veh) then 
        Entity(veh).state.inBennys = nil
    end
end


function tryPay(user_id,price)
    if config.tryPay then
        return config.tryPay(user_id,price)
    else 
        return vRP.tryFullPayment(user_id,price)
    end

end

function func.repairVehicle(vehicle, damage)
    if vehicle and damage then
        local source = source
        local user_id = vRP.getUserId(source)
        local price = math.floor(250+150* ((1000-damage)/100))
        if config.repair_price then
            price = parseInt(config.repair_price)
        end
        if tryPay(user_id,price) then
            return true
        else
            if config.servermsg then
                TriggerClientEvent("Notify",source,"negado",config.servermsg[3](format(price)),5000)
            else
                TriggerClientEvent("Notify",source,"negado","Você não possui <b>$"..format(price).."</b>.",5000)
            end
        end
    end
    return false
end


function func.checkPayment(cart, model, plate)
    local source = source
    local user_id = vRP.getUserId(source)
    local money = parseInt((vRP.getBankMoney(user_id) or 0) + (vRP.getMoney(user_id) or 0))
    local value = cart["total"]
    if value and user_id then
        if (config.tryPayMods and config.tryPayMods(source,user_id,cart, model, plate)) or (not config.tryPayMods and tryPay(user_id,value)) then
            return true
        else
            if money < value and config.servermsg then
                TriggerClientEvent("Notify",source,"negado",config.servermsg[3](format(value)),5000)
            elseif money < value then
                TriggerClientEvent("Notify",source,"negado","Você não possui <b>$"..format(value).."</b>.",5000)
            end
        end
    end
    return false
end


function func.saveVehicle(vehname,vehplate,custom,netid)
    TriggerEvent("nation:updateVehicleMods", vehplate, netid)
    if config.saveVehicle then
        config.saveVehicle(vehplate,custom,vehname,netid)
    else
        local vehuser = vRP.getVehiclePlate(vehplate) or vRP.getUserByRegistration(vehplate)
        if vehuser then
            vRP.setSData("custom:u"..vehuser.."veh_"..vehname,json.encode(custom))
        end
    end
    local vehicle = NetworkGetEntityFromNetworkId(netid)
    if DoesEntityExist(vehicle) then
        checkVehicleTyres(netid, custom)
    end
end



function func.getTunnerChip(name)
    local source = source
    local user_id = vRP.getUserId(source)
    local tuning = vRP.getSData("custom:u"..user_id.."t_veh_"..name) or {}
    local custom = json.decode(tuning) or nil
    if custom == nil then
        return false,custom
    else
        return true,custom
    end
end

function func.getSavedMods(vehname,vehplate)
    if config.getSavedMods then
        return config.getSavedMods(vehplate, vehname)
    end
    local vehuser = vRP.getVehiclePlate(vehplate) or vRP.getUserByRegistration(vehplate)
    if vehuser then
        local data = vRP.getSData("custom:u"..vehuser.."veh_"..vehname)
        local custom = json.decode(data)
        if custom then
            return custom
        end
    end
    return false
end


function func.syncMods(vnet, custom, damage)
    local source = source
    if not serverScript then return end
    local vehicle = NetworkGetEntityFromNetworkId(vnet)
    if DoesEntityExist(vehicle) then
        checkVehicleTyres(vnet, custom)
        if damage then
            local owner = NetworkGetEntityOwner(vehicle) or source
            fclient._applyMods(owner, custom, vnet, damage);
        end
    end
end


function checkVehicleTyres(netid, tuning)
    if GetResourceState("nation-garages") == "started" then return end
    local vehicle = NetworkGetEntityFromNetworkId(netid)
    if DoesEntityExist(vehicle) then
        local state = Entity(vehicle).state
        state.tuning = tuning
        if type(tuning.bulletProofTyres) == "boolean" and tuning.bulletProofTyres == false and not vehicleTyres[netid] then
            vehicleTyres[netid] = true
            GlobalState.vehicleTyres = vehicleTyres
        elseif vehicleTyres[netid] then
            vehicleTyres[netid] = false
            GlobalState.vehicleTyres = vehicleTyres
            CreateThread(function()
                Wait(3000)
                vehicleTyres[netid] = nil
                GlobalState.vehicleTyres = vehicleTyres
            end)
        end
        Wait(2000)
        state.tuning = nil
    else
        vehicleTyres[netid] = nil
        GlobalState.vehicleTyres = vehicleTyres
    end
end

AddEventHandler('entityRemoved',function(entity)
    if DoesEntityExist(entity) then
        local netid = NetworkGetNetworkIdFromEntity(entity)
        if vehicleTyres[netid] then
            vehicleTyres[netid] = nil
            GlobalState.vehicleTyres = vehicleTyres
        end
    end
end)

--[[ CreateThread(function()
    while true do
        for netid, vehData in pairs(vehicleTyres) do
            checkVehicleTyres(netid)
        end
        Wait(2000)
    end
end) ]]


RegisterServerEvent('nation:syncApplyMods')
AddEventHandler('nation:syncApplyMods',func.syncMods)

RegisterServerEvent('nation:syncTunnerChip')
AddEventHandler('nation:syncTunnerChip',function(custom,vnet)
    if not serverScript then return end
    TriggerClientEvent('nation:applytunnerchip',-1,custom,vnet)
end)

RegisterServerEvent('nation_bennys:debug')
AddEventHandler('nation_bennys:debug',function(plate, custom)
    print("\nAPLICANDO MODS PLACA "..plate)
	print("MODS:\n")
	print(json.encode(custom))
end)



