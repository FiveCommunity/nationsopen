scriptLoaded = true
local Tunnel = Tunnel or  module("vrp",config.clientTunnel or "lib/Tunnel")
local Proxy = Proxy or module("vrp",config.clientProxy or "lib/Proxy")
vRP = Proxy.getInterface("vRP")
func = Tunnel.getInterface("nation_bennys")
fclient = {}
Tunnel.bindInterface("nation_bennys", fclient)
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIÁVEIS
-----------------------------------------------------------------------------------------------------------------------------------------
local nui = false
local block = false
local vehicle
vehicles = {}
local myveh = {}
local cam = nil
local gameplaycam = nil
local damage = tonumber("1000.0")
local cart = {["total"] = 0}
local prices = function(modType, vehicle)
	if config.getModPrice then
		return config.getModPrice(modType, vehicle)
	end
	return config.prices[modType] or { startprice = 0, increaseby = 0 }
end

local colors = {
	["cromado"] = {120},
	["metalico"] = {
		0, 147, 1, 11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 27, 28, 29, 150, 30, 31, 32, 33, 34, 
		143, 35, 135, 137, 136, 36, 38, 138, 99, 90, 88, 89, 91, 49, 50, 51, 52, 53, 54, 
		92, 141, 61, 62, 63, 64, 65, 66, 67, 68, 69, 73, 70, 74, 96, 101, 95, 94, 97,
		103, 104, 98, 100, 102, 99, 105, 106, 71, 72, 142, 145, 107, 111, 112
	},
	["fosco"] = {12,13,14,131,83,82,84,149,148,39,40,41,42,55,128,151,155,152,153,154},
	["metal"] = { 117,118,119,158,159 }
}
for i = 161, 242 do
	table.insert(colors["cromado"],i)
end



local mod = {
	["aerofolio"] = 0,
	["parachoque-dianteiro"] = 1,
	["parachoque-traseiro"] = 2,
	["saias"] = 3,
	["escapamento"] = 4,
	["roll-cage"] = 5,
	["grelha"] = 6,
	["capo"] = 7,
	["para-lama"] = 8,
	["right-fender"] = 9,
	["teto"] = 10,
	["motor"] = 11,
	["freios"] = 12,
	["transmissao"] = 13,
	["buzina"] = 14,
	["suspensao"] = 15,
	["blindagem"] = 16,
	["turbo"] = 18,
	["smoke"] = 20,
	["farol"] = 22,
	["dianteira"] = 23,
	["traseira"] = 24,
	["plate-holder"] = 25,
	["vanity-plates"] = 26,
	["trim-design"] = 27,
	["ornaments"] = 28,
	["dashboard"] = 29,
	["dials"] = 30,
	["doors"] = 31,
	["seats"] = 32,
	["steering-wheel"] = 33,
	["shift-lever"] = 34,
	["plaques"] = 35,
	["speaker"] = 36,
	["trunk"] = 37,
	["hydraulics"] = 38,
	["engine-block"] = 39,
	["air-filter"] = 40,
	["struts"] = 41,
	["arch-cover"] = 42,
	["aerials"] = 43,
	["trim"] = 44,
	["tank"] = 45,
	["janela"] = 46,
	["decal"] = 48,
	["lightbar"] = 49,
}

local wheeltype = {
	["stock"] = -1,
	["sport"] = 0,
	["muscle"] = 1,
	["lowrider"] = 2,
	["suv"] = 3,
	["offroad"] = 4,
	["tuner"] = 5,
	["highend"] = 7,
	["bennys"] = 8,
	["bespoke"] = 9,
	["open"] = 10,
	["street"] = 11,
	["track"] = 12,
}







-----------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADS
-----------------------------------------------------------------------------------------------------------------------------------------
local bennys = {}
Citizen.CreateThread(function()
	Wait(5000)
	SendNUIMessage({ action = "resourceName", resourceName = GetCurrentResourceName() })
	while scriptLoaded do
		if not nui then
			local locais = config.locais
			local playercoords = GetEntityCoords(PlayerPedId())
			for i in ipairs(locais) do
				local coords = locais[i]
				if type(coords) == "table" then
					coords = coords[1]
				end
				local distance = #(playercoords - coords)
				if distance < 10 and not bennys[i] then
					bennys[i] = locais[i]
				elseif bennys[i] and distance > 10 then
					bennys[i] = nil
				end
			end
		end
		Citizen.Wait(500)
	end
end)

Citizen.CreateThread(function()
	SetNuiFocus(false,false)
	while scriptLoaded do 
		local idle = 500
		if not nui and length(bennys) > 0 then
			idle = 0
			for _, v in pairs(bennys) do 
				local coords = v
				local perm = false
				if type(coords) == "table" then
					coords = coords[1]
					perm = v.perm
				end
				if config.marker then
					config.marker(coords[1],coords[2],coords[3])
				else
					DrawMarker(27, coords[1],coords[2],coords[3]-0.97 ,0,0,0,0,0,0,f(3.0),f(3.0),f(1.0),255, 102, 0,200,0,0,0,1)
					DrawMarker(36, coords,0,0,0,0,0,0,f(1.0),f(3.0),f(1.0),255, 102, 0,200,0,0,0,1)
				end
				local playercoords = GetEntityCoords(PlayerPedId())
				local distance = #(playercoords - coords)
				if distance < 2 then
					if config.clientmsg then
						drawTxt(config.clientmsg[4],4,0.5,0.93,0.50,255,255,255,180)
					else
						drawTxt("PRESSIONE  ~r~E~w~  PARA ACESSAR A ~y~MECÂNICA",4,0.5,0.93,0.50,255,255,255,180)
					end
					if IsControlJustPressed(0,38) then
						vehicle = getNearestVehicle(7)
						if vehicle and isVehicleReady(vehicle) then
							local class = GetVehicleClass(vehicle)
							if (class == 8 or class == 13) and config.moto_permission and func.checkMotoPermission() and func.checkVehicle(VehToNet(vehicle)) then
								startTuning(vehicle, v)
							elseif config.moto_permission and class ~= 8 and class ~= 13 and func.checkPermission(perm) and func.checkVehicle(VehToNet(vehicle)) then
								startTuning(vehicle, v)
							elseif not config.moto_permission and func.checkPermission(perm) and func.checkVehicle(VehToNet(vehicle)) then
								startTuning(vehicle, v)
							end
						end
					end
				end
			end
		end
		Citizen.Wait(idle)
	end
end)

function isVehicleReady(vehicle)
	local model = GetEntityModel(vehicle)
	local seats = GetVehicleModelNumberOfSeats(model) - 2
	for i = -1 , seats do
		local ped = GetPedInVehicleSeat(vehicle, i)
		if DoesEntityExist(ped) and ped ~= PlayerPedId() then
			return false
		end
	end
	if not NetworkGetEntityIsNetworked(vehicle) then return false end
	return true
end

function fclient.updateVehicles(vehs)
	vehicles = vehs
end


RegisterNetEvent('nation:startTunning')
AddEventHandler('nation:startTunning',function()
	vehicle = getNearestVehicle(7)
	if vehicle and NetworkGetEntityIsNetworked(vehicle) then
		if func.checkVehicle(VehToNet(vehicle)) then
			startTuning(vehicle)
		end
	end
end)

function startTuning(vehicle, bennys)
	if not DoesEntityExist(vehicle) then return end
	local ped = PlayerPedId()
	if NetworkGetEntityOwner(vehicle) ~= PlayerId() then
		while DoesEntityExist(vehicle) and NetworkGetEntityOwner(vehicle) ~= PlayerId() do
			NetworkRequestControlOfEntity(vehicle)
        	Wait(10)
		end
	end
	damage = GetVehicleBodyHealth(vehicle)
	if config.no_repair then
		damage = tonumber("1000.0")
	end
	SetVehicleModKit(vehicle,0)
	myveh = getAllVehicleMods(vehicle)
	gameplaycam = GetRenderingCam()
	cam = CreateCam("DEFAULT_SCRIPTED_CAMERA",true,2)
	SendNUIMessage({ action = "vehicle", vehicle = getVehicleMods(vehicle), damage = damage, logo = config.logo })
	showNui(bennys)
	TriggerEvent("nation_bennys:stats", true)
	isVehicleTooFar(vehicle)
end

AddEventHandler("onResourceStop",function()
	if vehicle and DoesEntityExist(vehicle) then
		FreezeEntityPosition(vehicle,false)
	end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------




-----------------------------------------------------------------------------------------------------------------------------------------
-- CALLBACKS
-----------------------------------------------------------------------------------------------------------------------------------------

RegisterNUICallback("close",function(data)
	SetVehicleLights(vehicle,0)
	if IsHornActive(vehicle) then
		StartVehicleHorn(vehicle, 0, "NORMAL", false)
	end
	fclient.closeNui()
end)

RegisterNUICallback("voltar",function(data)
	if IsHornActive(vehicle) then
		StartVehicleHorn(vehicle, 0, "NORMAL", false)
	end
end)

RegisterNUICallback("cam",function(data)
	if data and data.cam then
		if data.cam == "freecam" then
			freeCam()
		else
			camControl(data.cam)
		end
	end
end)

function getVehicleModelName(hash)
    for _,v in ipairs(GetAllVehicleModels()) do
        if GetHashKey(v) == hash then
            return v
        end
    end
    return ""
end

RegisterNUICallback("pagar",function(data)
	if cart["total"] and func.checkPayment(cart, GetEntityModel(vehicle), GetVehicleNumberPlateText(vehicle)) then
		SetNuiFocus(false,false)
		SendNUIMessage({ action = "applying" })
		if not IsPedInAnyVehicle(PlayerPedId()) then
			if config.playAnim then
				config.playAnim()
			else
				playAnim("mini@repair","fixing_a_player")
			end
		end
		if config.clientmsg then
			TriggerEvent("progress",10000,config.clientmsg[5])
		else
			TriggerEvent("progress",10000,"aplicando modificações")
		end
		Wait(10000)
		if DoesEntityExist(vehicle) then
			if config.clientmsg then
				TriggerEvent("Notify","sucesso",config.clientmsg[1],5000)
			else
				TriggerEvent("Notify","sucesso","Modificações aplicadas com <b>sucesso</b>.",5000)
			end
			ClearPedTasks(PlayerPedId())
			myveh = getAllVehicleMods(vehicle)
			local vehname = getVehicleModelName(GetEntityModel(vehicle))
			local vehplate = GetVehicleNumberPlateText(vehicle)
			if vehplate then
				vehplate = string.gsub(vehplate, "%s+", "")
			end
			func.saveVehicle(vehname,vehplate,myveh,VehToNet(vehicle))
		end
		fclient.closeNui()
	end
end)

function playAnim(dict,anim)
	RequestAnimDict(dict)
	while not HasAnimDictLoaded(dict) do
		RequestAnimDict(dict)
		Wait(10)
	end
	TaskPlayAnim(PlayerPedId(), dict,anim, 3.0, 3.0, -1, 48,0,0,0,0)
end

RegisterNUICallback("callbacks",function(data, cb)
	if data then
		if data.type == "reparar" then
			if block then
				return
			end
			block = true
			if func.repairVehicle(vehicle,damage) then
				SetVehicleDoorOpen(vehicle, 4, 0, 0)
				if not IsPedInAnyVehicle(PlayerPedId()) then
					if config.playAnim then
						config.playAnim()
					else
						playAnim("mini@repair","fixing_a_player")
					end
				end
				if config.clientmsg then
					TriggerEvent("progress",10000,config.clientmsg[6])
				else
					TriggerEvent("progress",10000,"reparando")
				end
				Wait(10000)
				if DoesEntityExist(vehicle) then
					local fuel = GetVehicleFuelLevel(vehicle)
					SetVehicleFixed(vehicle)
					SetVehicleFuelLevel(vehicle, fuel)
					SetVehicleEngineHealth(vehicle, tonumber("1000.0"))
					SetVehicleDirtLevel(vehicle,tonumber("0.0"))
					SetVehicleUndriveable(vehicle,false)
					SetEntityAsMissionEntity(vehicle,true,true)
					SetVehicleOnGroundProperly(vehicle)
					if config.clientmsg then
						TriggerEvent("Notify","sucesso",config.clientmsg[2],5000)
					else
						TriggerEvent("Notify","sucesso","Veículo reparado com <b>sucesso</b>.",5000)
					end
					damage = tonumber("1000.0")
					TriggerServerEvent("nation:fixVehicle",VehToNet(vehicle))
				end
				ClearPedTasks(PlayerPedId())
				SendNUIMessage({ action = "repair" })
			end
			block = false
		elseif data.type == "cor-primaria" or data.type == "cor-secundaria" then
			local color = split(data.color, ",")
			vehicleCustomColor(data.type, vehicle, color)
		elseif string.find(data.type, "sticker") then
			local sticker = parseInt(split(data.type, "-")[2])
			SetVehicleLivery(vehicle, sticker)
			updateCart(myveh, 'sticker', sticker)
		elseif string.find(data.type, "turbo") then
			local turbo = parseInt(split(data.type, "-")[2])
			if turbo > 0 then
				ToggleVehicleMod(vehicle,mod["turbo"],true)
			else
				ToggleVehicleMod(vehicle,mod["turbo"],false)
			end
			updateCart(myveh, mod["turbo"], turbo)
		elseif string.find(data.type,"motor") or string.find(data.type,"freios") or string.find(data.type,"transmissao") or string.find(data.type,"suspensao") then
			local type = split(data.type,"-")[1]
			local level = parseInt(split(data.type, "-")[2]) - 1
			SetVehicleMod(vehicle,mod[type],level)
			updateCart(myveh, mod[type], level)
		elseif string.find(data.type, "neon") then
			local type = split(data.type, "-")[2]
			if type == "kit" then
				setNeon(vehicle,true)
				updateCart(myveh, "neon", 1)
			elseif type == "default" then
				setNeon(vehicle,false)
				updateCart(myveh, "neon", 0)
			elseif type == "colors" then
				local color = split(data.color, ",")
				neonColor(vehicle,color)
			end
			SetVehicleLights(vehicle,2)
		elseif string.find(data.type, "farol") then
			SetVehicleLights(vehicle,2)
			local type = split(data.type, "-")[2]
			if type then
				if type == "xenon" then
					setXenon(vehicle,true)
					updateCart(myveh, mod["farol"], 1)
				else
					setXenon(vehicle,false)
					updateCart(myveh, mod["farol"], 0)
				end
			end
		elseif string.find(data.type,"xenon") then
			local colorindex = parseInt(split(data.type, "-")[3])
			SetVehicleXenonLightsColour(vehicle,colorindex)
		elseif string.find(data.type,"pneus") then
			local type = split(data.type, "-")[1]
			local modindex = GetVehicleMod(vehicle,mod["dianteira"])
			if type == "fabrica" then
				SetVehicleMod(vehicle,mod["dianteira"],modindex,false)
				SetVehicleTyresCanBurst(vehicle,true)
				if GetGameBuildNumber() >= 2372 then
					SetDriftTyresEnabled(vehicle,false)
				end
				updateCart(myveh, "fabrica", 0)
			elseif type == "custom" then
				SetVehicleMod(vehicle,mod["dianteira"],modindex,true)
				updateCart(myveh, "custom", 1)
			elseif type == "bulletproof" then
				SetVehicleTyresCanBurst(vehicle,false)
				updateCart(myveh, "bulletproof", 1)
			elseif type == "drift" then
				if GetGameBuildNumber() >= 2372 then
					SetDriftTyresEnabled(vehicle,not GetDriftTyresEnabled(vehicle))
					updateCart(myveh, "drift", 1)
				end
			end
		elseif string.find(data.type,"smoke") then
			local color = split(data.color, ",")
			smokeColor(vehicle,color)
			updateCart(myveh, "smoke", color)
		elseif string.find(data.type, "primaria") or string.find(data.type, "secundaria") then
			local type = split(data.type, "-")[2]
			local color = split(data.type, "-")[3]
			local colorindex = split(data.type, "-")[4]
			if colors[color] then
				if #colors[color] > 1 and colorindex then
					colorindex = parseInt(colorindex)
					vehicleColor(type,vehicle,colors[color][colorindex],color)
				else
					vehicleColor(type,vehicle,colors[color][1],color)
				end
			end
		elseif string.find(data.type, "blindagem") then
			local blindagem = data.blindagem
			if blindagem then
				SetVehicleMod(vehicle,mod["blindagem"],blindagem)
			end
			updateCart(myveh, mod["blindagem"], blindagem)
		elseif string.find(data.type, "placa") then
			local type = parseInt(split(data.type, "-")[2])
			SetVehicleNumberPlateTextIndex(vehicle,type)
			updateCart(myveh, "placa", type)
		elseif string.find(data.type, "vidro") then
			local tint = parseInt(split(data.type, "-")[2])
			SetVehicleWindowTint(vehicle,tint)
			updateCart(myveh, "vidro", tint)
		elseif string.find(data.type, "perolado") then
			local colorindex = split(data.type, "-")[3]
			if colorindex then
				vehiclePerolado(vehicle,parseInt(colorindex))
				updateCart(myveh, "perolado", colorindex)
			end
		elseif string.find(data.type, "wheelcolor") then
			local colorindex = split(data.type, "-")[2]
			if colorindex then
				vehicleWheelColor(vehicle,parseInt(colorindex))
				updateCart(myveh, "wheelcolor", colorindex)
			end
		elseif string.find(data.type, "extras") then
			local extra = tonumber(split(data.type, "-")[2])
			local disable = IsVehicleExtraTurnedOn(vehicle,extra) == 1
			SetVehicleExtra(vehicle, extra, disable and 1 or 0)
			local extras = {}
			for extraId=0, 14 do
				if DoesExtraExist(vehicle, extraId) then
					extras[tostring(extraId)] = IsVehicleExtraTurnedOn(vehicle, extraId) == 1
				end
			end
			cb(extras)
			updateCart(myveh, "extras", extra, extras)
		elseif wheeltype[data.type] or wheeltype[split(data.type,"-")[1]] then
			local type = wheeltype[data.type]
			local index = -1
			if not type then
				type = wheeltype[split(data.type,"-")[1]]
				index = parseInt(split(data.type,"-")[2])-1
			end
			SetVehicleWheelType(vehicle,type)
			SetVehicleMod(vehicle,mod["dianteira"],index,false)
			updateCart(myveh, mod["dianteira"], index)
		elseif (mod[split(data.type,"-")[1]] or mod[tostring(split(data.type,"-")[1].."-"..split(data.type,"-")[2])]) and parseInt(split(data.type,"-")[2]) then
			local modType = mod[split(data.type,"-")[1]]
			local index = parseInt(split(data.type,"-")[2]) - 1
			if split(data.type,"-")[3] then
				modType = mod[split(data.type,"-")[1].."-"..split(data.type,"-")[2]]
				index = parseInt(split(data.type,"-")[3]) - 1
			end
			SetVehicleMod(vehicle,modType,index,false)
			if modType == mod["buzina"] then
				StartVehicleHorn(vehicle, 5000, "HELDDOWN", true)
			end
			updateCart(myveh, modType, index)
		end
	end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- FUNÇÕES
-----------------------------------------------------------------------------------------------------------------------------------------

-- PEGAR O TAMANHO DA TABLE (ÍNDICES NÃO ORDENADOS) --
function length(array)
	local len = 0
	for i in pairs(array) do 
		if array[i] then
			len = len+1
		end
	end
	return len
end


function updateCart(myveh, modtype, index, colortype)
	if myveh == nil or modtype == nil or index == nil then
		return
	end
	if modtype == "extras" then
		local extras = colortype
		local price = 50
		if prices(modtype, vehicle) and prices(modtype, vehicle).startprice then
			price = prices(modtype, vehicle).startprice
		end
		for k,enable in pairs(extras) do
			local i = modtype.."-"..k
			if enable and not myveh.extras[tostring(k)] and not cart[i] then
				cart[i] = 1
				cart["total"] = cart["total"] + price
			elseif not enable and cart[i] then
				cart[i] = nil
				cart["total"] = cart["total"] - price
			end
		end
	elseif modtype == "smoke" then
		if cart[tostring(modtype)] == nil then
			cart[tostring(modtype)] = 1
			local price = 50
			if prices(modtype, vehicle) and prices(modtype, vehicle).startprice then
				price = prices(modtype, vehicle).startprice
			end
			cart["total"] = cart["total"] + price
		end
	elseif modtype == mod["turbo"] or modtype == mod["farol"] then
		if cart[tostring(modtype)] == nil then
			if myveh.mods[modtype].mod < 1 and index > 0 then
				cart[tostring(modtype)] = 1
				cart["total"] = cart["total"] + prices(modtype, vehicle).startprice
			end
		elseif cart[tostring(modtype)] > 0 and index < 1 then
			cart["total"] = cart["total"] - prices(modtype, vehicle).startprice
			cart[tostring(modtype)] = nil
		end
	elseif modtype == "neon" then
		if cart[modtype] == nil then
			if not myveh.neon and index > 0 then
				cart[modtype] = 1
				cart["total"] = cart["total"] + prices(modtype, vehicle).startprice
			end
		elseif cart[modtype] > 0 and index < 1 then
			cart["total"] = cart["total"] - prices(modtype, vehicle).startprice
			cart[modtype] = nil
		end	
	elseif modtype == "bulletproof" or modtype == "custom" or modtype == "fabrica" or modtype == "drift" then
		if modtype == "fabrica" then
			if cart["bulletproof"] ~= nil then
				cart["total"] = cart["total"] - prices("bulletproof", vehicle).startprice
				cart["bulletproof"] = nil
			end
			if cart["custom"] ~= nil then
				cart["total"] = cart["total"] - prices("custom", vehicle).startprice
				cart["custom"] = nil
			end
			if cart["drift"] ~= nil then
				cart["total"] = cart["total"] - prices("drift", vehicle).startprice
				cart["drift"] = nil
			end
			SendNUIMessage({action = "price", price = cart["total"]})
			return
		end
		local type = not myveh.bulletProofTyres
		if modtype == "custom" then
			type = myveh.mods[mod["dianteira"]].variation
		elseif modtype == "drift" then
			type = myveh.driftTyre
		end
		if cart[modtype] == nil then
			if not type and index > 0 then
				cart[modtype] = 1
				cart["total"] = cart["total"] + prices(modtype, vehicle).startprice
			end
		elseif cart[modtype] > 0 and index < 1 then
			cart["total"] = cart["total"] - prices(modtype, vehicle).startprice
			cart[modtype] = nil
		end
	elseif modtype == "wheelcolor" or modtype == "perolado" then
		index = parseInt(index)
		local type = myveh.extracolor[1]
		if modtype == "wheelcolor" then
			type = myveh.extracolor[2]
		end
		if cart[modtype] == nil and type ~= index and index > 0 then
			cart[modtype] = index
			cart["total"] = cart["total"] + prices(modtype, vehicle).startprice
		elseif type ~= index and index > 0 then
			cart[modtype] = index
		elseif (index < 1 or type == index) and cart[modtype] ~= nil then
			cart["total"] = cart["total"] - prices(modtype, vehicle).startprice
			cart[modtype] = nil
		end
	elseif modtype == "primaria" or modtype == "secundaria" then
		local type = myveh.color[1]
		local vehcolortype = myveh.pcolortype
		local cartcolortype = cart["pcolortype"]
		if modtype == "secundaria" then
			type = myveh.color[2]
			vehcolortype = myveh.scolortype
			cartcolortype = cart["scolortype"]
		end
		if colortype and prices("colortypes", vehicle)[colortype] then
			if cartcolortype == nil and colortype ~= vehcolortype then
				local price = prices("colortypes", vehicle)[colortype]
				cartcolortype = colortype
				cart["total"] = cart["total"] + price
			elseif colortype == vehcolortype and prices("colortypes", vehicle)[cartcolortype] then
				local price = prices("colortypes", vehicle)[cartcolortype]
				cart["total"] = cart["total"] - price
				cartcolortype = nil
			elseif prices("colortypes", vehicle)[cartcolortype] then
				local price = prices("colortypes", vehicle)[cartcolortype]
				cart["total"] = cart["total"] - price
				cartcolortype = colortype
				price = prices("colortypes", vehicle)[colortype]
				cart["total"] = cart["total"] + price
			end
			if modtype == "primaria" then
				cart["pcolortype"] = cartcolortype
			else
				cart["scolortype"] = cartcolortype
			end
		end
		if cart[modtype] == nil and type ~= nil and index ~= nil and type ~= index and index > 0 then
			cart[modtype] = index
			cart["total"] = cart["total"] + prices(modtype, vehicle).startprice
		elseif type ~= nil and index ~= nil and type ~= index and index > 0 then
			cart[modtype] = index
		elseif (index < 1 or type == index) and cart[modtype] ~= nil then
			cart["total"] = cart["total"] - prices(modtype, vehicle).startprice
			cart[modtype] = nil
		end
	elseif modtype == "cor-primaria" or modtype == "cor-secundaria" then
		local type = myveh.customPcolor
		if modtype == "cor-secundaria" then
			type = myveh.customScolor
		end
		if cart[modtype] == nil and not sameColor(index,type) then
			cart[modtype] = index
			cart["total"] = cart["total"] + prices(modtype, vehicle).startprice
		elseif sameColor(index,type) then
			cart["total"] = cart["total"] - prices(modtype, vehicle).startprice
			cart[modtype] = nil
		end
	elseif modtype == "vidro" then
		if cart[modtype] == nil and myveh.windowtint ~= index and index > 0 then
			cart[modtype] = index
			cart["total"] = cart["total"] + (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(index-1))
		elseif myveh.windowtint ~= index and index > 0 then
			cart["total"] = cart["total"] - (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(cart[modtype]-1))
			cart[modtype] = index
			cart["total"] = cart["total"] + (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(index-1))
		elseif (index < 1 or myveh.windowtint == index) and cart[modtype] ~= nil then
			cart["total"] = cart["total"] - (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(cart[modtype]-1))
			cart[modtype] = nil
		end
	elseif modtype == "placa" then
		if cart[modtype] == nil and myveh.plateindex ~= index and index > 0 then
			cart[modtype] = index
			cart["total"] = cart["total"] + (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(index-1))
		elseif myveh.plateindex ~= index and index > 0 then
			cart["total"] = cart["total"] - (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(cart[modtype]-1))
			cart[modtype] = index
			cart["total"] = cart["total"] + (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(index-1))
		elseif (index < 1 or myveh.plateindex == index) and cart[modtype] ~= nil then
			cart["total"] = cart["total"] - (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(cart[modtype]-1))
			cart[modtype] = nil
		end
	elseif modtype == "sticker" then
		if cart[modtype] == nil and myveh.sticker ~= index and index > 0 then
			cart[modtype] = index
			cart["total"] = cart["total"] + (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(index-1))
		elseif myveh.sticker ~= index and index > 0 then
			cart["total"] = cart["total"] - (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(cart[modtype]-1))
			cart[modtype] = index
			cart["total"] = cart["total"] + (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(index-1))
		elseif (index < 1 or myveh.sticker == index) and cart[modtype] ~= nil then
			cart["total"] = cart["total"] - (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * p(cart[modtype]-1))
			cart[modtype] = nil
		end
	elseif cart[tostring(modtype)] == nil and myveh.mods[modtype].mod ~= index and index > -1 then
		cart[tostring(modtype)] = index
		cart["total"] = cart["total"] + (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * index)
	elseif myveh.mods[modtype].mod ~= index and index > -1 then
		cart["total"] = cart["total"] - (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * cart[tostring(modtype)])
		cart[tostring(modtype)] = index
		cart["total"] = cart["total"] + (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * index)
	elseif (index < 0 or myveh.mods[modtype].mod == index) and cart[tostring(modtype)] ~= nil then
		cart["total"] = cart["total"] - (prices(modtype, vehicle).startprice + prices(modtype, vehicle).increaseby * cart[tostring(modtype)])
		cart[tostring(modtype)] = nil
	end
	SendNUIMessage({action = "price", price = cart["total"]})
end

function p(nro)
	if nro < 0 then
		return 0
	end
	return nro
end

function getAllVehicleMods(veh)
	local myveh = {}
	myveh.vehicle = veh
	myveh.color =  table.pack(GetVehicleColours(veh))
	myveh.customPcolor = table.pack(GetVehicleCustomPrimaryColour(veh))
	myveh.customScolor = table.pack(GetVehicleCustomSecondaryColour(veh))
	myveh.extracolor = table.pack(GetVehicleExtraColours(veh))
	myveh.neon = hasNeonKit(veh)
	myveh.neoncolor = table.pack(GetVehicleNeonLightsColour(veh))
	myveh.xenoncolor = GetVehicleHeadlightsColour(veh)
	myveh.smokecolor = table.pack(GetVehicleTyreSmokeColor(veh))
	myveh.plateindex = GetVehicleNumberPlateTextIndex(veh)
	myveh.pcolortype = getColorType(myveh.color[1])
	myveh.scolortype = getColorType(myveh.color[2])
	myveh.sticker = GetVehicleLivery(veh)
	myveh.dashColour = GetVehicleDashboardColor(veh)
    myveh.interColour = GetVehicleInteriorColor(veh)
	myveh.mods,myveh.extras = {},{}
	for i = 0, 49 do
		myveh.mods[i] = {mod = nil}
	end
	for i,t in pairs(myveh.mods) do 
		if i == 22 or i == 18 then
			if IsToggleModOn(veh,i) then
				t.mod = 1
			else
				t.mod = 0
			end
		elseif i == 23 or i == 24 then
			t.mod = GetVehicleMod(veh,i)
			t.variation = GetVehicleModVariation(veh, i)
		else
			t.mod = GetVehicleMod(veh,i)
		end
	end
	if GetVehicleWindowTint(veh) == -1 or GetVehicleWindowTint(veh) == 0 then
		myveh.windowtint = false
	else
		myveh.windowtint = GetVehicleWindowTint(veh)
	end
	if myveh.xenoncolor > 12 or myveh.xenoncolor < -1 then
		myveh.xenoncolor = -1
	end
	myveh.wheeltype = GetVehicleWheelType(veh)
	myveh.bulletProofTyres = GetVehicleTyresCanBurst(veh)
	for extraId=0, 14 do
        if DoesExtraExist(veh, extraId) then
            myveh.extras[tostring(extraId)] = IsVehicleExtraTurnedOn(veh, extraId) == 1
        end
    end
    myveh.driftTyre = GetGameBuildNumber() >= 2372 and GetDriftTyresEnabled(veh)
	return myveh
end

AddStateBagChangeHandler("tuning", nil, function (bagName, key, value)
	local entity = GetEntityFromStateBagName(bagName);
	if not DoesEntityExist(entity) or Entity(entity).state.spawned or GetResourceState("nation-garages") == "started" then return end
	setVehicleMods(entity,value)
end)

function setVehicleMods(veh,myveh)
	SetVehicleModKit(veh,0)
	if not myveh or not myveh.customPcolor or not DoesEntityExist(veh) then
		return
	end
	if config.showDebug then
		local plate = GetVehicleNumberPlateText(veh)
		TriggerServerEvent("nation_bennys:debug", plate, myveh)
	end
	ClearVehicleCustomPrimaryColour(veh)
	ClearVehicleCustomSecondaryColour(veh)
	local bug = false
	local cprimary = myveh.customPcolor
	if cprimary['1'] then
		bug = true
	end

	if bug then
		SetVehicleCustomPrimaryColour(veh,cprimary['1'],cprimary['2'],cprimary['3'])
	else
		SetVehicleCustomPrimaryColour(veh,cprimary[1],cprimary[2],cprimary[3])
	end

	if not myveh.color then return end
	local primary = myveh.color[1]
	local secondary = myveh.color[2]
	local csecondary = myveh.customScolor
	local perolado = myveh.extracolor[1]
	local wheelcolor = myveh.extracolor[2]
	local neoncolor = myveh.neoncolor
	local smokecolor = myveh.smokecolor
	local sticker = myveh.sticker
	SetVehicleLivery(veh, myveh.sticker or 0)
	SetVehicleWheelType(veh,myveh.wheeltype)
	SetVehicleColours(veh,primary,secondary)
	if bug then
		SetVehicleCustomPrimaryColour(veh,cprimary['1'],cprimary['2'],cprimary['3'])
		SetVehicleCustomSecondaryColour(veh,csecondary['1'],csecondary['2'],csecondary['3'])
	else
		SetVehicleCustomPrimaryColour(veh,cprimary[1],cprimary[2],cprimary[3])
		SetVehicleCustomSecondaryColour(veh,csecondary[1],csecondary[2],csecondary[3])
	end
	SetVehicleExtraColours(veh,perolado,wheelcolor)
	SetVehicleNeonLightsColour(veh,neoncolor[1],neoncolor[2],neoncolor[3])
	SetVehicleXenonLightsColour(veh,myveh.xenoncolor)
	SetVehicleNumberPlateTextIndex(veh,myveh.plateindex)
	SetVehicleWindowTint(veh,myveh.windowtint)
	for i,t in pairs(myveh.mods) do 
		if tonumber(i) == 22 or tonumber(i) == 18 then
			if t.mod > 0 then
				ToggleVehicleMod(veh,tonumber(i),true)
			else
				ToggleVehicleMod(veh,tonumber(i),false)
			end
		elseif tonumber(i) == 20 then
			smokeColor(veh,smokecolor)
		elseif tonumber(i) == 23 or tonumber(i) == 24 then
			SetVehicleMod(veh,tonumber(i),tonumber(t.mod),tonumber(t.variation))
		else
			SetVehicleMod(veh,tonumber(i),tonumber(t.mod))
		end
	end
	SetVehicleTyresCanBurst(veh,myveh.bulletProofTyres)
	if myveh.neon then
		for i = 0, 3 do
			SetVehicleNeonLightEnabled(veh,i,true)
		end
	else
		for i = 0, 3 do
			SetVehicleNeonLightEnabled(veh,i,false)
		end
	end
	if myveh.extras then
		local body = GetVehicleBodyHealth(veh)
		for extraId,enabled in pairs(myveh.extras) do
			if enabled then
            	SetVehicleExtra(veh, tonumber(extraId), 0)
			end
        end
        for extraId,enabled in pairs(myveh.extras) do
			if not enabled and IsVehicleExtraTurnedOn(veh, tonumber(extraId)) then
				SetVehicleExtra(veh, tonumber(extraId), 1)
			end
        end
		SetVehicleBodyHealth(veh, body)
    end
end



function getVehicleMods(veh)
	rodaatual = GetVehicleMod(veh,mod["dianteira"])
	local mods = {
		["cor-primaria"] = rgbToHex({GetVehicleCustomPrimaryColour(veh)}),
		["cor-secundaria"] = rgbToHex({GetVehicleCustomSecondaryColour(veh)}),
		["neon"] = IsVehicleNeonLightEnabled(veh,2),
		["neon-colors"] = rgbToHex({GetVehicleNeonLightsColour(veh)}),
		["smoke-colors"] = rgbToHex({GetVehicleTyreSmokeColor(veh)}),
		["custom-pneus"] = GetVehicleModVariation(veh,mod["dianteira"]),
		["bulletproof-pneus"] = not GetVehicleTyresCanBurst(veh),
		["fabrica-pneus"] = not GetVehicleModVariation(veh,mod["dianteira"]) and GetVehicleTyresCanBurst(veh) and (GetGameBuildNumber() < 2372 or not GetDriftTyresEnabled(veh)),
		["drift-pneus"] = GetGameBuildNumber() >= 2372 and GetDriftTyresEnabled(veh),
		["farol"] = IsToggleModOn(veh,mod["farol"]),
		["turbo"] = IsToggleModOn(veh,mod["turbo"]),
		["placa"] = { GetNumberOfVehicleNumberPlates(), GetVehicleNumberPlateTextIndex(veh)-1 },
		["vidro"] = { GetNumVehicleWindowTints()+2, GetVehicleWindowTint(veh)-1 },
		["bike"] = IsThisModelABike(GetEntityModel(veh)),
		["sticker"] = { GetVehicleLiveryCount(veh), GetVehicleLivery(veh) },
		["extras"] = {},
		["colors"] = colors
	}
	for k in pairs(wheeltype) do
		mods[k] = { isWheelType(k) }
	end
	SetVehicleMod(veh,mod["dianteira"], rodaatual, mods["custom-pneus"])
	for k in pairs(mod) do
		if mods[k] == nil then
			mods[k] = { GetNumVehicleMods(veh, mod[k])+1, GetVehicleMod(veh,mod[k]) }
		end
	end
	for extraId=0, 14 do
        if DoesExtraExist(veh, extraId) then
            mods.extras[tostring(extraId)] = IsVehicleExtraTurnedOn(veh, extraId) == 1
        end
    end
	return mods
end

function hasNeonKit(veh)
	for i = 0, 3 do 
		if not IsVehicleNeonLightEnabled(veh,i) then 
			return false 
		end 
	end 
	return true
end

function setNeon(veh,toggle)
	for i = 0, 3 do
		SetVehicleNeonLightEnabled(veh,i,toggle)
	end
end

function setXenon(veh,toggle)
	ToggleVehicleMod(veh,mod["farol"],toggle)
end

function isWheelType(type)
	local type = wheeltype[type]
	local bool = false
	local wheel = 0
	local num = 0
	local wtype = GetVehicleWheelType(vehicle)
	if wtype == type then
		bool = true
		wheel = rodaatual
	end
	local currentRearWheels = GetVehicleMod(vehicle,24)
	SetVehicleWheelType(vehicle,type)
	num = GetNumVehicleMods(vehicle,mod["dianteira"])
	SetVehicleWheelType(vehicle,wtype)
	SetVehicleMod(vehicle, 24, currentRearWheels)
	return bool, wheel, num

end

function vehicleCustomColor(type,veh,color)
	local r,g,b = parseInt(color[1]),parseInt(color[2]),parseInt(color[3])
	if type == "cor-primaria" then
		SetVehicleCustomPrimaryColour(veh,r,g,b)
		updateCart(myveh, type, {r,g,b})
	elseif type == "cor-secundaria" then
		SetVehicleCustomSecondaryColour(veh,r,g,b)
		updateCart(myveh, type, {r,g,b})
	end
end

function sameColor(c1,c2)
	if c1[1] ~= c2[1] or c1[2] ~= c2[2] or c1[3] ~= c2[3] then
		return false
	end
	return true
end

function neonColor(veh,color)
	local r,g,b = parseInt(color[1]),parseInt(color[2]),parseInt(color[3])
	SetVehicleNeonLightsColour(veh,r,g,b)
end

function smokeColor(veh,color)
	local r,g,b = parseInt(color[1]),parseInt(color[2]),parseInt(color[3])
	ToggleVehicleMod(veh,mod["smoke"],true)
	SetVehicleTyreSmokeColor(veh,r,g,b)
end

function vehicleColor(type,veh,color,colortype)
	SetVehicleModKit(veh,0)
	local p,s = GetVehicleColours(veh)
	if type == "primaria" then
		ClearVehicleCustomPrimaryColour(veh)
		SetVehicleColours(veh,color,s)
	elseif type == "secundaria" then
		ClearVehicleCustomSecondaryColour(veh)
		SetVehicleColours(veh,p,color)
		SetVehicleInteriorColour(veh,color)
    	SetVehicleDashboardColour(veh,color)
	end
	updateCart(myveh, type, color,colortype)
end

function vehiclePerolado(veh,i)
	local perolado,wcolor = GetVehicleExtraColours(veh)
	SetVehicleExtraColours(veh,i,wcolor)
end

function vehicleWheelColor(veh,i)
	local perolado,wcolor = GetVehicleExtraColours(veh)
	SetVehicleExtraColours(veh,perolado,i)
end

function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end

function rgbToHex(rgb)
	local hexadecimal = '#'
	for key, value in pairs(rgb) do
		local hex = ''
		while(value > 0)do
			local index = math.fmod(value, 16) + 1
			value = math.floor(value / 16)
			hex = string.sub('0123456789ABCDEF', index, index) .. hex			
		end
		if(string.len(hex) == 0)then
			hex = '00'
		elseif(string.len(hex) == 1)then
			hex = '0' .. hex
		end
		hexadecimal = hexadecimal .. hex
	end
	return hexadecimal
end

function getColorType(color)
	for k,v in pairs(colors) do
		for i,j in pairs(v) do
			if j == color then
				return k
			end
		end
	end
	return false
end


function getNearestVehicles(radius)
	local r = {}
	local px,py,pz = table.unpack(GetEntityCoords(PlayerPedId()))

	local vehs = {}
	local it,veh = FindFirstVehicle()
	if veh then
		table.insert(vehs,veh)
	end
	local ok
	repeat
		ok,veh = FindNextVehicle(it)
		if ok and veh then
			table.insert(vehs,veh)
		end
	until not ok
	EndFindVehicle(it)

	for _,veh in pairs(vehs) do
		local x,y,z = table.unpack(GetEntityCoords(veh,true))
		local distance = GetDistanceBetweenCoords(x,y,z,px,py,pz,true)
		if distance <= radius then
			r[veh] = distance
		end
	end
	return r
end

function getNearestVehicle(radius)
	local veh
	local vehs = getNearestVehicles(radius)
	local min = radius+0.0001
	for _veh,dist in pairs(vehs) do
		if dist < min then
			min = dist
			veh = _veh
		end
	end
	return veh 
end

function drawTxt(text,font,x,y,scale,r,g,b,a)
	SetTextFont(font)
	SetTextScale(scale,scale)
	SetTextColour(r,g,b,a)
	SetTextOutline()
	SetTextCentre(1)
	SetTextEntry("STRING")
	AddTextComponentString(text)
	DrawText(x,y)
end

function isVehicleTooFar(veh)
	Citizen.CreateThread(function()
		while nui and DoesEntityExist(veh) do
			local vehcoords = GetEntityCoords(veh)
			local playercoords = GetEntityCoords(PlayerPedId())
			local distance = #(playercoords - vehcoords)
			if distance > 7 then
				if config.clientmsg then
					TriggerEvent("Notify","aviso",config.clientmsg[3],5000)
				else
					TriggerEvent("Notify","aviso","Você se afastou muito do veículo.",5000)
				end
				break
			elseif NetworkGetEntityOwner(veh) ~= PlayerId() then
				break
			end
			Citizen.Wait(500)
		end
		fclient.closeNui()
	end)

end





------------------ CAMERA----------------------------------

function f(n)
	return (n + 0.00001)
end

local function PointCamAtBone(bone,ox,oy,oz)
	-- SetCamActive(cam, true)
	local veh = vehicle
	local b = GetEntityBoneIndexByName(veh, bone)
	if b and b > -1 then
		local bx,by,bz = table.unpack(GetWorldPositionOfEntityBone(veh, b))
		local ox2,oy2,oz2 = table.unpack(GetOffsetFromEntityGivenWorldCoords(veh, bx, by, bz))
		local x,y,z = table.unpack(GetOffsetFromEntityInWorldCoords(veh, ox2 + f(ox), oy2 + f(oy), oz2 +f(oz)))
		SetCamCoord(cam, x, y, z)
		PointCamAtCoord(cam,GetOffsetFromEntityInWorldCoords(veh, 0, oy2, oz2))
		RenderScriptCams( 1, 1, 1000, 0, 0)
	end
end

local function MoveVehCam(pos,x,y,z)
	-- SetCamActive(cam, true)
	local veh = vehicle
	local vx,vy,vz = table.unpack(GetEntityCoords(veh))
	local d = GetModelDimensions(GetEntityModel(veh))
	local length,width,height = d.y*-2, d.x*-2, d.z*-2
	local ox,oy,oz
	if pos == 'front' then
		ox,oy,oz= table.unpack(GetOffsetFromEntityInWorldCoords(veh, f(x), (length/2)+ f(y), f(z)))
	elseif pos == "front-top" then
		ox,oy,oz= table.unpack(GetOffsetFromEntityInWorldCoords(veh, f(x), (length/2) + f(y),(height) + f(z)))
	elseif pos == "back" then
		ox,oy,oz= table.unpack(GetOffsetFromEntityInWorldCoords(veh, f(x), -(length/2) + f(y),f(z)))
	elseif pos == "back-top" then
		ox,oy,oz= table.unpack(GetOffsetFromEntityInWorldCoords(veh, f(x), -(length/2) + f(y),(height/2) + f(z)))
	elseif pos == "left" then
		ox,oy,oz= table.unpack(GetOffsetFromEntityInWorldCoords(veh, -(width/2) + f(x), f(y), f(z)))
	elseif pos == "right" then
		ox,oy,oz= table.unpack(GetOffsetFromEntityInWorldCoords(veh, (width/2) + f(x), f(y), f(z)))
	elseif pos == "middle" then
		ox,oy,oz= table.unpack(GetOffsetFromEntityInWorldCoords(veh, f(x), f(y), (height/2) + f(z)))
	end
	SetCamCoord(cam, ox, oy, oz)
	PointCamAtCoord(cam,GetOffsetFromEntityInWorldCoords(veh, 0, 0, f(0)))
	RenderScriptCams( 1, 1, 1000, 0, 0)
end



function camControl(c)
	if c == "parachoque-dianteiro" or c == "grelha" or c == "arch-cover" then
		MoveVehCam('front',-0.6,1.5,0.4)
	elseif c == "cor-primaria" or c == "cor-secundaria" or c == "decal" then
		MoveVehCam('middle',-2.6,2.5,1.4)
	elseif  c == "parachoque-traseiro"  or c == "escapamento" then
		MoveVehCam('back',-0.5,-1.5,0.2)
	elseif c == "capo" then
		MoveVehCam('front-top',-0.5,1.3,f(1.0))
	elseif c == "teto" then
		MoveVehCam('middle',-2.2,2,1.5)
	elseif c == "vidro" then
		MoveVehCam('middle',f(-2.0),2,0.5)
	elseif c == "farol" or c == "xenon-colors" then
		MoveVehCam('front',-0.6,1.3,0.6)
	elseif c == "placa" or c == "plate-holder" or c == "right-fender" then
		MoveVehCam('back',0,-1,0.2)
	elseif c == "para-lama" then
		MoveVehCam('left',-1.8,-1.3,0.7)
	elseif c == "saias" then
		MoveVehCam('left',-1.8,-1.3,0.7)
	elseif c == "aerofolio" or c == "trunk" then
		MoveVehCam('back',0.5,-1.6,1.3)
		if c == "trunk" then
			SetVehicleDoorOpen(vehicle, 5, 0, 0)
			SetVehicleDoorOpen(vehicle, 4, 0, 0)
			doorsopen = true
		end
	elseif c == "traseira" then
		PointCamAtBone("wheel_lr",-1.4,0,0.3)
	elseif c == "dianteira" or c == "wheel-accessories" or  c == "wheel-colors" or wheeltype[c] then
		PointCamAtBone("wheel_lf",-1.4,0,0.3)
	elseif c == "neon" or c == "neon-colors" or c == "suspensao" then
		if not IsThisModelABike(GetEntityModel(vehicle)) then
			PointCamAtBone("neon_l",f(-2.0),f(2.0),0.4)
		end
	elseif c == "janela" or c == "interior" or c == "ornaments" or c == "dashboard" or c == "dials" or c == "seats" or c =="roll-cage" then
		MoveVehCam('back-top',f(0.0),f(4.0),0.7)
	elseif c == "doors" then
		SetVehicleDoorOpen(vehicle, 0, 0, 0)
		SetVehicleDoorOpen(vehicle, 1, 0, 0)
		doorsopen = true
	elseif c == "speaker" or  c == "engine-block" or c == "air-filter" or c == "struts" or c == "hydraulics" then
		SetVehicleDoorOpen(vehicle, 5, 0, 0)
		SetVehicleDoorOpen(vehicle, 4, 0, 0)
		doorsopen = true
		if c == "speaker" then
			MoveVehCam('back',0.5,-1.6,1.3)
		end
	elseif c == "shift-lever" or c == "steering-wheel" or c == "trim-design" then
		ResetCam()
		SetFollowVehicleCamViewMode(4)
	elseif doorsopen then--IsCamActive(cam) then
		ResetCam()
		tryResetDoors(vehicle)
	else
		ResetCam()
		tryResetDoors(vehicle)
	end
end

function tryResetDoors(vehicle)
	if isVehicleDoorsOpened(vehicle) or doorsopen then
		SetVehicleDoorShut(vehicle, 0, 0)
		SetVehicleDoorShut(vehicle, 1, 0)
		SetVehicleDoorShut(vehicle, 4, 0)
		SetVehicleDoorShut(vehicle, 5, 0)
		SetVehicleFixed(vehicle)
		doorsopen = false
		local x,y,z = table.unpack(GetEntityCoords(PlayerPedId()))
		ClearAreaOfVehicles(x,y,z,5.0,false,false,false,false,false)
		ClearAreaOfEverything(x,y,z,5.0,false,false,false,false)
	end
end

function isVehicleDoorsOpened(vehicle)
	for i = 0, 6 do
		if IsVehicleDoorFullyOpen(vehicle , i ) then
			return true
		end
	end
	return false
end

function ResetCam()
	SetCamCoord(cam,GetGameplayCamCoords())
	SetCamRot(cam, GetGameplayCamRot(2), 2)
	RenderScriptCams( 0, 1, 1000, 0, 0)
	-- SetCamActive(gameplaycam, true)
	-- EnableGameplayCam(true)
	-- SetCamActive(cam, false)
	SetFollowVehicleCamViewMode(0)
end

function freeCam()
	Citizen.CreateThread(function()
		SetNuiFocus(false,false)
		ResetCam()
		local freecam = true
		while freecam and nui do
			Citizen.Wait(1)
			if IsControlJustPressed(0,74) or IsControlJustPressed(0,85) then
				freecam = false
				SetNuiFocus(true,true)
				SendNUIMessage({ action = "cam" })
			end
		end
	end)
end


------------------------------------------------------------

function showNui(bennys)
	SetNuiFocus(true,true)
	local t, p, l = false
	if type(bennys) == "table" then
		t = bennys.opcoes
		p = bennys.pneus
		l = bennys.logo
	end
	SendNUIMessage({ action = "showMenu", options = t, pneus = p, logo = l })
	nui = true
end


function fclient.closeNui()
	if IsCamActive(cam) then
		SetCamActive(cam, false)
	end
	ResetCam()
	SetNuiFocus(false,false)
	SendNUIMessage({ action = "hideMenu" })
	camControl("close")
	if DoesEntityExist(vehicle) then
		local netid = VehToNet(vehicle)
		func._removeVehicle(netid)
		if not NetworkHasControlOfEntity(vehicle) then
			func._syncMods(VehToNet(vehicle), myveh,damage)
		else
			SetVehicleLights(vehicle,0)
			setVehicleMods(vehicle,myveh, true)
			SetVehicleBodyHealth(vehicle,damage)
		end
	end
	nui = false
	vehicle = nil
	cam = nil
	damage = tonumber("1000.0")
	cart = {["total"] = 0}
	myveh = {}
	TriggerEvent("nation_bennys:stats", false)
end

-----------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------


RegisterNetEvent("nation:applymods")
AddEventHandler("nation:applymods", function(veh,vname)
	if not scriptLoaded then return end
	if veh then
		local vehname = vname or getVehicleModelName(GetEntityModel(veh))
		local vehplate = GetVehicleNumberPlateText(veh)
		local tunner_on
		local tunner_customs
		if config.tunner_chip then
			tunner_on, tunner_customs = func.getTunnerChip(vehname)
			if tunner_on then
				TriggerServerEvent("nation:syncTunnerChip", tunner_customs, VehToNet(veh))
			end
		end
		if vehplate then
			vehplate = string.gsub(vehplate, "%s+", "")
		end
		local custom = func.getSavedMods(vehname,vehplate)
		if custom then
			func._syncMods(VehToNet(veh), custom)
		else
			TriggerEvent("vrp_garages:applymods", VehToNet(veh), custom)
		end
	end
end)


function fclient.applyMods(custom, vnet, damage)
	if not scriptLoaded then return end
	if NetworkDoesEntityExistWithNetworkId(vnet) then
		local veh = NetToVeh(vnet)
		if DoesEntityExist(veh) then
			if custom and custom.customPcolor and custom.customScolor then
				if DoesEntityExist(veh) then
					setVehicleMods(veh,custom)
					SetVehicleLights(veh,0)
					if damage then
						SetVehicleBodyHealth(veh,damage)
					end
				end
			end
		end
	end
end

RegisterNetEvent('nation:applymods_sync')
AddEventHandler('nation:applymods_sync',fclient.applyMods)


RegisterNetEvent('nation:applytunnerchip')
AddEventHandler('nation:applytunnerchip',function(tunner_customs,vnet)
	if NetworkDoesEntityExistWithNetworkId(vnet) then
		local veh = NetToVeh(vnet)
		if DoesEntityExist(veh) then
			if tunner_customs then
				SetVehicleHandlingFloat(veh, "CHandlingData", "fInitialDriveForce", tunner_customs.boost * f(1.0))
        		SetVehicleHandlingFloat(veh, "CHandlingData", "fDriveInertia", tunner_customs.fuelmix * f(1.0))
        		SetVehicleEnginePowerMultiplier(veh, tunner_customs.gearchange * f(1.0))
        		SetVehicleHandlingFloat(veh, "CHandlingData", "fBrakeBiasFront", tunner_customs.braking * f(1.0))
        		SetVehicleHandlingFloat(veh, "CHandlingData", "fDriveBiasFront", tunner_customs.drivebiass * f(1.0))
        		SetVehicleHandlingFloat(veh, "CHandlingData", "fBrakeForce", tunner_customs.brakeforce * f(1.0))
			end
		end
	end
end)






local vehicleTyres = GlobalState.vehicleTyres or {}
AddStateBagChangeHandler("vehicleTyres",nil,function(_,_,value) vehicleTyres = value end)
CreateThread(function()
    while true do
		for netid, bulletproof in pairs(vehicleTyres) do
            if NetworkDoesEntityExistWithNetworkId(netid) then 
                local veh = NetworkGetEntityFromNetworkId(netid)
                if DoesEntityExist(veh) and GetVehicleTyresCanBurst(veh) ~= bulletproof and not Entity(veh).state.inBennys then
                    SetVehicleTyresCanBurst(veh, not bulletproof)
                end
            end
        end
        Wait(1000)
    end
end)